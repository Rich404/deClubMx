package com.rebollocorp.ricardo.declubmx;

/**
 * Created by hpadmin on 20/07/17.
 */
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class GridViewAdapter extends  BaseAdapter{

    Context mContext;
    String[] gridViewString;
    Bitmap[] moBitmap;

    public GridViewAdapter(Context context, String[] gridViewString,Bitmap[] moBitmap) {
        mContext = context;
        this.gridViewString = gridViewString;
        this.moBitmap = moBitmap;
    }

    @Override
    public int getCount() {
        return moBitmap.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        View gridViewAndroid = new View(mContext);
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null)
        {
            gridViewAndroid = inflater.inflate(R.layout.grid_view_adapter, null);
            TextView textViewAndroid = (TextView) gridViewAndroid.findViewById(R.id.android_gridview_text);
            ImageView imageViewAndroid = (ImageView) gridViewAndroid.findViewById(R.id.android_gridview_image);
            textViewAndroid.setText(gridViewString[i]);
            LoadImageWithBitMap LI =  new LoadImageWithBitMap(imageViewAndroid);
            LI.execute(moBitmap[i]);
        } else {
            gridViewAndroid = (View) convertView;
        }

        return gridViewAndroid;
    }


}
