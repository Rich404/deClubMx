<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>  
<body style="background-color:#24384C;">  
<div class="container">

      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
        <h3 class="text-muted"> <font color="#FDF4E3">Administración - DeClubMx </font></h3>
      </div>
                        <?php
                                /*$ValtxtUsuario = $_POST['txtUsuario'];
                                $ValtxtPass = $_POST['txtPassword'];
                                $Valcombo = $_POST['comboType'];
                                echo "Usuario:".$ValtxtUsuario."<br> ";
                                echo "Password:".$ValtxtPass . "<br>";
                                echo "Type:" . $Valcombo; */
                                // Get cURL resource
                              
                              $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|COUNT(*)|AS|UserState|FROM|declub_users|WHERE|user_id|=|'".$_POST['txtUsuario']."'|AND|user_password|=|'".$_POST['txtPassword']."'|AND||user_type|=|'".$_POST['comboType']."'|AND|isVisible|=|1|;");
                              $jsonObjectArray = json_decode($response, true);
                              //echo $jsonObjectArray[0]["UserState"];
                              
                              
                              switch ($jsonObjectArray[0]["UserState"]) {
                                case "0":
                                    //echo "No Hay Registro";
                                    echo "
                                    <div class=\"embed-responsive embed-responsive-16by9\">
                                          <iframe class=\"embed-responsive-item\" src=\"http://localhost/declubmx/FailPage.html\" allowfullscreen></iframe>
                                      </div>";
                                    break;
                                case "1":
                                    //echo "Ok --- ";
                                    echo "
                                    <div class=\"embed-responsive embed-responsive-16by9\">
                                          <iframe class=\"embed-responsive-item\" src=\"http://localhost/declubmx/deClubMx".$_POST['comboType'].".php\" allowfullscreen></iframe>
                                      </div>";
                                    
                                    break;
                                default:
                                    echo "Ha Ocurrido Un Error, Regrese más tarde";
                              }
                              
                              function executeHttpRequest($URL) {
                                
                                $curl = curl_init();
                                // Set some options - we are passing in a useragent too here
                                curl_setopt_array($curl, array(
                                    CURLOPT_RETURNTRANSFER => 1,
                                    CURLOPT_URL => $URL,
                                    CURLOPT_USERAGENT => 'deClubmx HttpRequest'
                                ));
                                // Send the request & save response to $resp
                                $resp = curl_exec($curl);
                                // Close request to clear up some resources
                                curl_close($curl);
                                return $resp;

                              }
                        ?>
      
</div>
</body>
</html>
