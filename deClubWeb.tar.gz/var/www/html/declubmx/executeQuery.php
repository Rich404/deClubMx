<!--
    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *
    *   Desarrollado por : Ricardo Camacho Tenorio  Año: 2018   *   
    *   Contacto : ricardo.camacho.info@gmail.com               *
    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *
-->
<?php

	$servername = "localhost";
	$username = "root";
	$password = "admin";
        $dbname = "declubmx_app_maintenance";
	$connetionObj = mysqli_connect($servername, $username, $password,$dbname);
	 mysqli_set_charset($connetionObj, "utf8"); //formato de datos utf8
	if ($connetionObj == false)
	{
		die("Error en la conexion: " . mysqli_connect_error());	
	}
	else
	{
		//echo "Conexion establecida";
		$sqlQuery = str_replace("|"," ",$_GET["query"]) . ";";
		//echo "<br>"."Se ejecutara: ". $sqlQuery . "<br>";
		$resultOfQuery = mysqli_query($connetionObj, $sqlQuery);
		
		/*if (mysqli_num_rows($resultOfQuery) > 0) 
		{
			
			 $emparray = array();
			    while($row =mysqli_fetch_assoc($resultOfQuery))
			    {
				$emparray[] = $row;
			    }
			    echo json_encode($emparray);
		} 
		else 
		{
		    	echo "<br>" . "Error Query";
		} */
		if(!$resultOfQuery) 
		{
			echo "<br> Error: ". mysql_error() ;		
   		}
   		else
   		{
   			$emparray = array();
			while($row =mysqli_fetch_assoc($resultOfQuery))
			{
				$emparray[] = $row;
			}
			echo json_encode($emparray);
   		}
   
		
		
	}
	mysqli_close($connetionObj);
	
?>
