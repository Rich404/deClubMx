<?php
	$servername = "localhost";
	$username = "root";
	$password = "admin";
        $dbname = "test";

	// Create connection
	$conn = mysqli_connect($servername, $username, $password,$dbname);

	// Check connection
	if ($conn == false)
	{
	    die(" Error en la conexion: " . mysqli_connect_error());
	}
	echo "Conexion establecida";
        //mysqli_set_charset($conexion, "utf8"); //formato de datos utf8

	/*
	$sql = "select *  from table_test";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {
	    // output data of each row
	    while($row = mysqli_fetch_assoc($result)) {
		echo "<br>" . "id: " . $row["id"]. " - Name: " . $row["name"]. "<br>";
	    }
	} else {
	    echo "0 results";
	} */
	
	$sql = "select *  from table_test";
	if(!$result = mysqli_query($conn, $sql)) die(); //si la conexión cancelar programa

	    $rawdata = array(); //creamos un array

	    //guardamos en un array multidimensional todos los datos de la consulta
	    $i=0;

	    while($row = mysqli_fetch_array($result))
	    {
		$rawdata[$i] = $row;
		$i++;
	    }
	echo json_encode($rawdata);
	mysqli_close($conn);  }/*
    $connection = mysqli_connect("localhost","root","admin","declubmx_app_maintenance") or die("Error " . mysqli_error($connection));
	      mysqli_set_charset($connection, "utf8"); //formato de datos utf8
		
    $sql = "select * from declub_categories";
    $result = mysqli_query($connection, $sql) or die("Error in Selecting " . mysqli_error($connection));

    $emparray = array();
    while($row =mysqli_fetch_assoc($result))
    {
        $emparray[] = $row;
    }
    echo json_encode($emparray);

    mysqli_close($connection); */
?>
