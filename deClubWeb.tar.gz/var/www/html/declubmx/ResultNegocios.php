<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <style>
        .table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
          background-color: #AFAFAF;
        }
    </style> 
</head>  
<body style="background-color:#24384C;">  
    <br>
    <?php

    echo "Response: ". $_POST['id_shop'] ;
    ?>
 <div class="container" >
    <div class="well">
    <h2>Negocios</h2>
    <table class="table table-hover">
        <thead>
        <tr>
            <th>ID Negocio</th>
            <th>Nombre</th>
            <th>Fecha de Registro</th>
            <th>Tags de Búsqueda </th>
            <th>Datos</th>
            <th>Pagos</th>        
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>1</td>
            <td>Pizza Hut</td>
            <td>12-02-17</td>
            <td><button type="button" onclick="openPage('ViewTags.php')"  class="btn btn-default">Ver Tags</button></td>
            <td><button type="button" onclick="openPage('ViewNegocio.php')"  class="btn btn-info">Ver Datos</button></td>
            <td><button type="button" onclick="openPage('ViewPagos.php')" class="btn btn-warning">Ver Pagos</button></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Pizza Argetina</td>
            <td>12-05-17</td>
            <td><button type="button" onclick="openPage('ViewTags.php')" class="btn btn-default">Ver Tags</button></td>
            <td><button type="button"  onclick="openPage('ViewNegocio.php')" class="btn btn-info">Ver Datos</button></td>
            <td><button type="button" onclick="openPage('ViewPagos.php')" class="btn btn-warning">Ver Pagos</button></td>
        </tr>
        </tbody>
    </table>
    </div>
</div> 
<script type="text/javascript">
    function openPage(p1)
    {
            //AddTagByBusiness.php
            window.open(p1, "_blank" , "width=600,height=400,scrollbars=YES,left=400,top=200")
            //document.location.href = document.location.href; // truco para recargar asi mismo toda la pag. Es to por que los elementos de este funcion no estan ligados a un form que haga un reload.
    }
</script>
</body>
</html>