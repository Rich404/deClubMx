<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <style>
        .table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
          background-color: #AFAFAF;
        }
    </style> 
    <script type="text/javascript">
    function openPage(p1,domElementButton)
    {       
        //console.log(domElementButton);
        var domElemntTR = domElementButton.parentElement.parentElement;
        var selectedIndex =  domElemntTR.rowIndex;
        var selectdData = document.getElementById("tableResult").rows[selectedIndex].cells[0].innerHTML;
        
        
        window.open(p1 + "?id="+selectdData+"&ValidUser="+ document.getElementById("currentUser").value +"", "_blank" , "width=800,height=600,scrollbars=YES,left=400,top=200")
           //document.location.href = document.location.href; // truco para recargar asi mismo toda la pag. Es to por que los elementos de este funcion no estan ligados a un form que haga un reload.
        
    }
    function processView(DATA) {
        
        
        var Objtable = document.getElementById("tableResult"); // var Objtable = document.getElementById("tableResult").getElementsByTagName('tbody')[0];
        var rowPosition = Objtable.insertRow(Objtable.rows.length);
        var FieldsCount =  Objtable.rows[0].cells.length;
        var Fields = [];
        for(i = 0; i < FieldsCount; i++)
        {
            Fields[i] = rowPosition.insertCell(i);
           
        }
       
        var DataBP = DATA.split("|");
        //console.log(DataBP.length);
        for (i = 0; i < DataBP.length-1; i++) {// DataBP.length-1 se debe a que el,String trae un  "|" extra y split de lo cuenta como un item más. 
           
            var DataBTP = DataBP[i].split(":");
            

            //Fields[i].innerHTML = DataBTP[0];
            switch (DataBTP[0]) {
                case 'text':
                    Fields[i].innerHTML = DataBTP[2];
                break;
                case 'button':
                    Fields[i].innerHTML =  "<button type=\"button\" onclick=\"openPage('"+DataBTP[2]+"',this)\"  class=\"btn "+DataBTP[3]+"\"> "+DataBTP[1]+" </button>";
                break;
                case 'image':
                    Fields[i].innerHTML = "<img src=\""+DataBTP[2]+"\" alt=\"...\" class=\"\">";
                break;
            }

            
        }
        //document.getElementsByTagName("tr")[Objtable.rows.length-1].setAttribute("onclick", "openPage('',this)");// asignamos un nuevo attributo para el elemneto TR  (table row) creo .. eso significa
        //var x = document.getElementById("btnx").parentElement.parentElement; Obtiene el elemento HTML antecesor y parentElemnt.nodeName Para obtener el nombre del elemento html
       

    }
    function removeDom()
    {
                var elem = document.getElementById("tableResult");
                elem.remove();
    }
</script>
</head>  
<body style="background-color:#24384C;">  
    <br>
 <div class="container" >
    <div class="well">
    <h2>Negocios</h2>
    
    <table class="table table-hover" id="tableResult">
        <thead>
        <tr>
            <th>ID Negocio</th>
            <th>Nombre</th>
            <th>Fecha de Registro</th>
            <th>Tags de Búsqueda </th>
            <th>Datos</th>
            <th>Pagos</th>
        </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
    </div>
   <?php
        
        if(empty($_POST['ValidUser']))
        {
            // no se puede continuar con el  filtrado de negocios , es posible que se esté intente accesar sin credenciales
            //echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
            //echo "<script>removeDom();</script>";
        }
        else
        {
            echo " <input type=\"hidden\" id=\"currentUser\" value=\"".$_POST['ValidUser']."\" >";
            $response  = NULL;
                  //OjbView sitax: type:value:config   (config) configuración de campo puede ser, algun un color o tamaño para un elemento, etc.          
            $fields = array("text:id_shop:none","text:shop_name:none","text:shop_registry:none","button:Ver Tags:btn-default","button:Ver Datos:btn-info","button:Ver Pagos:btn-warning"); 

            $isvisible = "false";
            if(!empty($_POST['chkActive']))
            {
                $isvisible = "true";
            }
            
            if(!empty($_POST['id_shop']))
            {
                $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|id_shop,shop_name,shop_registry,%27ViewTags%2Ephp%27|AS|%60Ver|Tags%60,%27ViewNegocio%2Ephp%27|AS|%60Ver|Datos%60,|%27ViewPagos%2Ephp%27|AS|%60Ver|Pagos%60|FROM|declub_shops|WHERE|id_shop|=|%27".$_POST['id_shop']."%27|AND|shop_name|=|shop_name|AND|isvisible|=|$isvisible;");
                //echo $response;
            
            }
            else
            {
                //echo " <font color=\"#FDF4E3\"> select id_shop,shop_name,isvisible from  declub_shops where id_shop = id_shop and  shop_name  like  '%".$_POST['shop_name']."%' and isvisible = $isvisible; </font>";
                $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|id_shop,shop_name,shop_registry,%27ViewTags%2Ephp%27|AS|%60Ver|Tags%60,%27ViewNegocio%2Ephp%27|AS|%60Ver|Datos%60,|%27ViewPagos%2Ephp%27|AS|%60Ver|Pagos%60|FROM|declub_shops|WHERE|id_shop|=id_shop|AND|shop_name|LIKE|%27%25".$_POST['shop_name']."%25%27|AND|isvisible|=|$isvisible;");
                //echo $response;
            
                
            }
            $response_decoded = json_decode($response,true);
            //echo count($response_decoded);
            
            for($i = 0; $i < count($response_decoded); ++$i) {
                
                $DataForResult = NULL;
                
                for($j=0;$j<count($fields);$j++)
                {
                    $ValueFields = NULL;
                    $ValueFields = split(":", $fields[$j]);
                    //echo   "<br>" . $response_decoded[$i][$ValueFields[1]];
                    //                  Tipo de Field      Nombre del Field     Valor de Field from decodedJsonArray     Property        
                    $DataForResult .=  $ValueFields[0].":".$ValueFields[1].":".$response_decoded[$i][$ValueFields[1]].":".$ValueFields[2]."|";

                }
                //echo "<br>" . $DataForResult;
                echo "<script>processView('". $DataForResult ."');</script>";
                 
            }

        }
        
        
        function executeHttpRequest($URL) {
            
            $curl = curl_init();
            // Set some options - we are passing in a useragent too here
            curl_setopt_array($curl, array(
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_URL => $URL,
                CURLOPT_USERAGENT => 'deClubmx HttpRequest'
            ));
            // Send the request & save response to $resp
            $resp = curl_exec($curl);
            // Close request to clear up some resources
            curl_close($curl);
            return $resp;

        }
        
    ?>
    <!-- button onclick="myFunction()">Try it</button> -->
</div> 
</body>
</html>