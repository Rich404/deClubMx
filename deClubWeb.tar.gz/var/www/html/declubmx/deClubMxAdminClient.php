<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <script type="text/javascript">
        function loadViewData(jsonData,field)
        {
            
              console.log(jsonData);
            if(jsonData != "[]")
            {
                var JsonData = JSON.parse(jsonData);
                var elementSelect = document.getElementById("selectShop");

                for (var i = 0; i < Object.keys(JsonData).length; i++) {
                    var elementOption = document.createElement("option");
                    elementOption.text = JsonData[i][field];
                    elementSelect.add(elementOption);    
                }
                


                /*var x = document.getElementById("mySelect");
                var option = document.createElement("option");
                option.text = "Kiwi";
                x.add(option); */
            }        
        }
    </script>
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container" >
             
            <br>
            <?php

                
                if(empty($_GET['ValidUser']))
                {
                  // no se puede continuar con el  filtrado de negocios , es posible que se esté intente accesar sin credenciales
                  echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
                  
                }
                else
                {
                  
                    echo"<form class=\"form-inline\">
                            <label for=\"comboMisNegocios\"><font color=\"#FDF4E3\"> Mis Negocios: </font></label>
                            <select id=\"selectShop\"class=\"form-control\" name=\"comboMisNegocios\">
                            <option>Pizza Hut</option>
                            <option>Helados XYZ</option>
                            </select>
                            
                            <button type=\"button\" class=\"btn btn-default btn-sm\">Aceptar</button>

                            <button onclick=\"reloadPage()\" type=\"button\" class=\"btn btn-default btn-sm\">
                                    <span class=\"glyphicon glyphicon-refresh\"></span>
                            </button>

                            <button data-toggle=\"tooltip\" data-placement=\"top\" title=\"Palabras clave para encontrar tu negocio\" onclick=\"openPage()\" type=\"button\" class=\"btn btn-warning btn-sm\">
                                    <span class=\"glyphicon glyphicon-search\"></span> Añadir Tags
                            </button>

                            <button type=\"button\" class=\"btn btn-primary btn-sm \">
                                    <span class=\"glyphicon glyphicon-plus\"></span> Nuevo Nogocio
                            </button>
                        </form>
                    ";
                    echo "<div class=\"embed-responsive embed-responsive-16by9\">
                    <iframe class=\"embed-responsive-item\" src=\"http://localhost/declubmx/SaveAndNewNegocio.php\" allowfullscreen ></iframe>
                        </div>";


                    $response  = NULL; // Json HttpSql request 
                    //executeRequest Curl  query
                    $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|shop_name|from|declub_shops|WHERE|user_id|=|%27".$_GET['ValidUser']."%27;");
                    echo "<script>loadViewData('".$response."','shop_name')</script>";
    
                }
                                
                function executeHttpRequest($URL) {
                    
                    $curl = curl_init();
                    // Set some options - we are passing in a useragent too here
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => $URL,
                        CURLOPT_USERAGENT => 'deClubmx HttpRequest'
                    ));
                    // Send the request & save response to $resp
                    $resp = curl_exec($curl);
                    // Close request to clear up some resources
                    curl_close($curl);
                    return $resp;
        
                }
                
                
            ?>
    </div>
    
<script>
    function openPage()
    {
        //AddTagByBusiness.php
        window.open("AddTagByBusiness.php", "AddTagPage" , "width=600,height=400,scrollbars=YES,left=400,top=200")
        //document.location.href = document.location.href; // truco para recargar asi mismo toda la pag. Es to por que los elementos de este funcion no estan ligados a un form que haga un reload.
    }
    function reloadPage() {
        location.reload();
    }
    
    $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
    });
</script> 
</body>
</html>