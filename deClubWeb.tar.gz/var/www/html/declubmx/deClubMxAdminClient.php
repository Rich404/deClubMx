<!--
    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *
    *   Desarrollado por : Ricardo Camacho Tenorio  Año: 2018   *   
    *   Contacto : ricardo.camacho.info@gmail.com               *
    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *
-->
<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <script type="text/javascript">
        function loadViewData(jsonData,field)
        {
            
              console.log(jsonData);
            if(jsonData != "[]")
            {
                var JsonData = JSON.parse(jsonData);
                var elementSelect = document.getElementById("selectShop");

                for (var i = 0; i < Object.keys(JsonData).length; i++) {
                    var elementOption = document.createElement("option");
                    elementOption.text = JsonData[i][field];
                    elementSelect.add(elementOption);    
                }
                


                /*var x = document.getElementById("mySelect");
                var option = document.createElement("option");
                option.text = "Kiwi";
                x.add(option); */
                
            }        
        }

        function addNewNegocio()
        {
            /*
            var date = new Date();

            console.log(date.getFullYear().toString().substring(2,4));
            //document.getElementById("resultFrame").src = "FailPage.html";
            */
            var nameNeg = prompt("Por favor ingrese un nombre para su negocio: ","Papa Jhones");
            if (nameNeg == null || nameNeg == "" || nameNeg.length < 3 ) {
                alert("No se ha podido validar el nombre para su negocio.");
            } else {
                var date = new Date();
                var user  = document.getElementById("ValidUser").value;
                var idShop = nameNeg.substring(0,2) + date.getFullYear().toString().substring(2,4) + date.getDay().toString() + user.substring(0,2) +date.getSeconds();
                document.getElementById("resultFrame").src = "SaveAndNewNegocio.php?ValidUser="+user+"&addNew="+"true"+"&id="+idShop+"&nameNeg="+nameNeg;
                
            }
        }
    </script>
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container" >
             
            <br>
            <?php

                
                if(empty($_GET['ValidUser']))
                {
                  // no se puede continuar con el  filtrado de negocios , es posible que se esté intente accesar sin credenciales
                  echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
                  
                }
                else
                {
                  
                    echo"<form class=\"form-inline\"  action=\"SaveAndNewNegocio.php\" target=\"resultFrame\" method=\"post\" >
                            <input type=\"hidden\" id=\"ValidUser\" name=\"ValidUser\" value=\"".$_GET['ValidUser']."\"><!-- input oculto -->
                            <label for=\"selectShop\"><font color=\"#FDF4E3\"> Mis Negocios: </font></label>
                            <select id=\"selectShop\"class=\"form-control\" name=\"selectShop\">
                            </select>

                            <button type=\"submit\" class=\"btn btn-success\"><span class=\"glyphicon glyphicon-filter\"></span></button>

                            <button onclick=\"reloadPage()\" type=\"button\" class=\"btn btn-default btn-sm\">
                                    <span class=\"glyphicon glyphicon-refresh\"></span>
                            </button>

                            <button data-toggle=\"tooltip\" data-placement=\"top\" title=\"Palabras clave para encontrar tu negocio\" onclick=\"openPage()\" type=\"button\" class=\"btn btn-warning btn-sm\">
                                    <span class=\"glyphicon glyphicon-search\"></span> Añadir Tags
                            </button>

                            <button onclick=\"addNewNegocio()\" type=\"button\" class=\"btn btn-primary btn-sm \">
                                    <span class=\"glyphicon glyphicon-plus\"></span> Nuevo Negocio
                            </button>
                        </form><br><br>
                    ";
                    echo "<div class=\"embed-responsive embed-responsive-16by9\">
                    <iframe class=\"embed-responsive-item\" name=\"resultFrame\" id=\"resultFrame\" src=\"http://localhost/declubmx/SaveAndNewNegocio.php\" allowfullscreen ></iframe>
                        </div>";


                    $response  = NULL; // Json HttpSql request 
                    //executeRequest Curl  query
                    $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|CONCAT(id_shop,%27|%27,shop_name)|AS|shop_name|FROM|declub_shops|WHERE|user_id|=|%27".$_GET['ValidUser']."%27;");
                    echo "<script>loadViewData('".$response."','shop_name')</script>";
    
                }
                                
                function executeHttpRequest($URL) {
                    
                    $curl = curl_init();
                    // Set some options - we are passing in a useragent too here
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => $URL,
                        CURLOPT_USERAGENT => 'deClubmx HttpRequest'
                    ));
                    // Send the request & save response to $resp
                    $resp = curl_exec($curl);
                    // Close request to clear up some resources
                    curl_close($curl);
                    return $resp;
        
                }
                
                
            ?>
    </div>
    
<script>
    function openPage()
    {
        //AddTagByBusiness.php
        var selectedValue = document.getElementById("selectShop").value
        var shop_data =  selectedValue.split(" ");
        //console.log(shop_data[0])
        window.open("AddTagByBusiness.php?id="+shop_data[0]+"&ValidUser="+ document.getElementById("ValidUser").value, "AddTagPage" , "width=600,height=400,scrollbars=YES,left=400,top=200")
        //document.location.href = document.location.href; // truco para recargar asi mismo toda la pag. Es to por que los elementos de este funcion no estan ligados a un form que haga un reload.
    }
    function reloadPage() {
        location.reload();
    }
    
    $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
    });
</script> 
</body>
</html>