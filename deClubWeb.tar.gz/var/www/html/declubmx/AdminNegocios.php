<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <style>
        .table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
          background-color: #AFAFAF;
        }
    </style> 
</head>  
<body style="background-color:#24384C;">
<?php
    
    if(empty($_GET['ValidUser']))
    {
      // no se puede continuar con el  filtrado de negocios , es posible que se esté intente accesar sin credenciales
      echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
      
    }
    else
    {
        //echo $_GET['ValidUser'];
        echo "<br>
        <div class=\"container\">
                <form class=\"form-inline\"  action=\"ResultNegocios.php\" target=\"my-iframe\" method=\"post\" >
                    <input type=\"hidden\" id=\"ValidUser\" name=\"ValidUser\" value=\"".$_GET['ValidUser']."\"><!-- input oculto -->
                    <div class=\"form-group\">
                        <label for=\"id_shop\"><font color=\"#FDF4E3\"> ID Negocio: </font></label>
                        <input type=\"text\" class=\"form-control\" id=\"id_shop\"  name=\"id_shop\">
                    </div>
                    <div class=\"form-group\">
                        <label for=\"shop_name\"><font color=\"#FDF4E3\"> Nombre: </font></label>
                        <input type=\"text\" class=\"form-control\" id=\"shop_name\"  name=\"shop_name\">
                    </div>
                    <div class=\"checkbox\">
                        <label><input value=\"true\" type=\"checkbox\" id=\"chkActive\" name=\"chkActive\">  <font color=\"#FDF4E3\"> Activo: </font></label>
                    </div>
                    <button type=\"submit\" class=\"btn btn-success\"><span class=\"glyphicon glyphicon-filter\"></span></button>
                </form>
                <div class=\"embed-responsive embed-responsive-16by9\">
                    <iframe  class=\"embed-responsive-item\" name=\"my-iframe\"  src=\"ResultNegocios.php\" allowfullscreen ></iframe>
                </div>
        </div>
        ";
    }
?>
</body>
</html>