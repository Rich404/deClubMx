<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <style>
        .table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
          background-color: #AFAFAF;
        }
    </style> 
</head>  
<body style="background-color:#24384C;">  
<br>
    <div class="container">
            <form class="form-inline"  action="ResultNegocios.php" target="my-iframe" method="post" >
                <div class="form-group">
                    <label for="id_shop"><font color="#FDF4E3"> ID Negocio: </font></label>
                    <input type="text" class="form-control" id="id_shop"  name="id_shop">
                </div>
                <div class="form-group">
                    <label for="shop_name"><font color="#FDF4E3"> Nombre: </font></label>
                    <input type="text" class="form-control" id="shop_name"  name="shop_name">
                </div>
                <div class="checkbox">
                    <label><input type="checkbox" name="">  <font color="#FDF4E3"> Activo: </font></label>
                </div>
                <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-filter"></span></button>
            </form>
            <div class="embed-responsive embed-responsive-16by9">
                <iframe  class="embed-responsive-item" name="my-iframe"  src="ResultNegocios.php" allowfullscreen ></iframe>
            </div>
    </div>
<script type="text/javascript">
</script>
</body>
</html>