<!--
    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *
    *   Desarrollado por : Ricardo Camacho Tenorio  Año: 2018   *   
    *   Contacto : ricardo.camacho.info@gmail.com               *
*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *
-->
<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <style>
        .table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
          background-color: #AFAFAF;
        }
    </style>
    <script type="text/javascript">
        

        function savenewTag()
        {
            var domtxtNewTag = document.getElementById("txtNewTag").value;
            
            if( domtxtNewTag != "" &&  domtxtNewTag.length > 2 )
            {
                //console.log(domtxtNewTag +"--"+ document.getElementById("id_shop").value)
                var id_shop = document.getElementById("id_shop").value;
                executeHttpRequest("INSERT|INTO|declub_tags|%28id_shop,shop_tag%29|VALUES|%28%27"+ id_shop +"%27,%27"+  domtxtNewTag +"%27%29;");
                
            }

        }
        function getParamsAndSendRequest(domElement)
        {
                
                var domElemntTR = domElement.parentElement.parentElement;
                var selectedIndex =  domElemntTR.rowIndex;
                var selectdData = document.getElementById("tableResult").rows[selectedIndex].cells[0].innerHTML;
                executeHttpRequest("DELETE|FROM|declub_tags|WHERE|id_tag|=|"+selectdData); 

        }

        /*function executeHttpRequest(arrayParameters) {


            //console.log(arrayParameters[0]);
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {

                    var jsonResponse = JSON.parse(xhttp.responseText); 
                    console.log(jsonResponse[0].batch_status);
                    if(jsonResponse[0].batch_status != '0')
                    {
                        alert(" Ha ocurrido un error al hacer la petición al servidor: " + jsonResponse[0].batch_status );
                    }
                    location.reload();    
                }
            };
            xhttp.open("GET", "http://localhost/declubmx/executeCommand.php?query="+ arrayParameters[0]+";", true);
            xhttp.send();
            
        }*/
        function executeHttpRequest(sqlBatch) {


            //console.log(arrayParameters[0]);
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {

                    var jsonResponse = JSON.parse(xhttp.responseText); 
                    console.log(jsonResponse[0].batch_status);
                    if(jsonResponse[0].batch_status != '0')
                    {
                        alert(" Ha ocurrido un error al hacer la petición al servidor: " + jsonResponse[0].batch_status );
                    }
                    location.reload();    
                }
            };
            xhttp.open("GET", "http://localhost/declubmx/executeCommand.php?query="+ sqlBatch, true);
            xhttp.send();
            
        }
        function processView(DATA) {
            //console.log(DATA);
            var Objtable = document.getElementById("tableResult"); // var Objtable = document.getElementById("tableResult").getElementsByTagName('tbody')[0];
            var rowPosition = Objtable.insertRow(Objtable.rows.length);
            var FieldsCount =  Objtable.rows[0].cells.length;
            var Fields = [];
            for(i = 0; i < FieldsCount; i++)
            {
                Fields[i] = rowPosition.insertCell(i);
            
            }
        
            var DataBP = DATA.split("|");
            //console.log(DataBP.length);
            for (i = 0; i < DataBP.length-1; i++) {// DataBP.length-1 se debe a que el,String trae un  "|" extra y split de lo cuenta como un item más. 
            
                var DataBTP = DataBP[i].split(":");
                

                //Fields[i].innerHTML = DataBTP[0];
                switch (DataBTP[0]) {
                    case 'text':
                        Fields[i].innerHTML = DataBTP[2];
                    break;
                    case 'button':
                        Fields[i].innerHTML =  "<button type=\"button\" onclick=\"getParamsAndSendRequest(this)\"  class=\"btn "+DataBTP[3]+"\"> "+DataBTP[2]+" </button>";
                    break;
                    case 'image':
                        Fields[i].innerHTML = "<img src=\""+DataBTP[2]+"\" alt=\"...\" class=\"\">";
                    break;
                }

                
            }

        }
        function removeDom()
        {
                var elem = document.getElementById("tableResult");
                elem.remove();
        }
    </script> 
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container">
    <div class="well">
    <h2>Tags - Criterios de búsqueda</h2>
           <div class="col-sm-2 pull-left">
                <input class="form-control" id="txtNewTag"  type="text" placeholder="tag para tu negocio" > 
            </div>
            <div class="pull-left">
                   <button  onclick="savenewTag()" type="button" class="btn btn-primary"> Añadir Tag </button> 
            </div>
    <table class="table table-hover " id="tableResult" >
        <thead>
        <tr>
            <th>ID Tag</th>
            <th>Negocio</th>
            <th>Tag</th>
            <th>Acción</th>
        </tr>
        </thead>
    </table>
   
    <?php
        
        if(empty($_GET['ValidUser']))
        {
            
            echo "  <center><h1> <font color=\"#000000\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
            echo "<script>removeDom();</script>";
        }
        else
        {
            echo "<input type=\"hidden\" id=\"id_shop\" value=\"".$_GET['id']."\">";
            $response  = NULL; // Json HttpSql request 
            //OjbView sitax: type:value:config   (config) configuración de campo puede ser, algun un color o tamaño para un elemento, etc.          
            $fields = array("text:id_tag:none","text:id_shop:none","text:shop_tag:none","button:BtnEliminar:btn-warning"); 
            //executeRequest Curl  query
            $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|id_tag,id_shop,shop_tag,%27Eliminar%27|AS|BtnEliminar|FROM||declub_tags|WHERE|id_shop|=|%27".$_GET['id']."%27;");
            
            // Parseando Json Repsonse
            $response_decoded = json_decode($response,true);
                        
            //Recoriendo el array de Jsonobjects
            for($i = 0; $i < count($response_decoded); ++$i) {
                
                //variable Para guardar, los datos de cada registro, (tipo,nombre,valor,propiedad)
                $DataForResult = NULL;
                //recorrer los Campos de  configuracion
                for($j=0;$j<count($fields);$j++)
                {
                    //variable Para guardar temporalmente cada registro creado u objeto final
                    $ValueFields = NULL;
                    //extrae por (:) los campos de configruacion
                    $ValueFields = split(":", $fields[$j]);

                    //                  Tipo de Field      Nombre del Field     Valor de Field from decodedJsonArray     Property  // Concatena los datos de cada Registro temporal        
                    $DataForResult .=  $ValueFields[0].":".$ValueFields[1].":".$response_decoded[$i][$ValueFields[1]].":".$ValueFields[2]."|";

                }
                //echo "<br>" . $DataForResult;
                echo "<script>processView('". $DataForResult ."');</script>";
                 
            }
            
            
        }
        function executeHttpRequest($URL) {
            
            $curl = curl_init();
            // Set some options - we are passing in a useragent too here
            curl_setopt_array($curl, array(
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_URL => $URL,
                CURLOPT_USERAGENT => 'deClubmx HttpRequest'
            ));
            // Send the request & save response to $resp
            $resp = curl_exec($curl);
            // Close request to clear up some resources
            curl_close($curl);
            return $resp;

        }
    ?>
    </div>
        <!--
        <div class="well">
    <h2>Tags - Criterios de búsqueda</h2>
    <table class="table table-hover">
        <thead>
        <tr>
            <th>ID Tag</th>
            <th>Negocio</th>
            <th>Tag</th>
            <th>Acción</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>1</td>
            <td>Pizza Hut</td>
            <td> comida rápida</td>
            <td><button type="button" class="btn btn-warning">Eliminar</button></td>
        </tr>
        </tbody>
    </table>
</div>-->
    </div>
<script type="text/javascript">
</script>
</body>
</html>