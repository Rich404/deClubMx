<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <script type="text/javascript">
        function removeDom()
        {
                var elem = document.getElementById("formData");
                elem.remove();
        }
        function loadViewData(JsonResponse,fieldsResponse)
        {
                var JsonData = JSON.parse(JsonResponse);
                console.log(JsonData[0]); 
                var fieldsData = fieldsResponse.split(":");
                for(var i=0;i < fieldsData.length;i++)
                {
                        console.log("Campo: " + fieldsData[i]);
                        document.getElementById(fieldsData[i]).innerHTML = JsonData[0][fieldsData[i]];
                }
                //console.log(JsonData[0]['isvisible']);
                

        }
    </script>     
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container" >

           <div class="well"> 
                <br>
                    <p  id="isvisible" class="text-success"  style="text-align:right;float:right;"> Activado <p style="text-align:right;float:right;">Status: </p> </p> 
                    <br>
                    <p  id="shop_registry" class="text-primary"  style="text-align:right;float:right;">27-Ago-2017<p style="text-align:right;float:right;"> Registro:</p> </p> 
                    <form lass="form-inline" role="form" id="formData">
                            <div class="form-group">
                                <label for="txtId"> <font color="#282828"> ID: </font></label>
                                <input disabled type="input" class="form-control" id="txtId" placeholder="-*-" name="txtId">
                            </div>
                            <div class="form-group">
                                <label for="checkIsVisible"> <font color="#282828"> Activo: </font></label>
                                <input  type="checkbox" class="" checked id="checkIsVisible" name="checkIsVisible">
                            </div>
                            <div class="form-group">
                                    <label for="txtNombre"> <font color="#282828"> Nombre: </font></label>
                                    <input type="input" class="form-control" id="txtNombre" placeholder="Nombre de Negoocio" required >
                            </div>
                            <div class="form-group  has-feedback">
                                    <label for="txtDescri"> <font color="#282828"> Descripción: </font></label>
                                    <textarea class="form-control" placeholder="Describe tu Negocio" rows="2" id="txtDescri" required ></textarea>
                                    <i class="  glyphicon glyphicon-list-alt form-control-feedback"></i>                                
                            </div>

                            <div class="form-group">  
                                    <label for="comboCategoria"> <font color="#282828"> Categoria: </font></label>
                                    <select class="form-control" name="comboCategoria">
                                            <option>Pizzeria</option>
                                            <option>Refaccionarias</option>
                                    </select>   
                            </div>
                            <div class="form-group has-feedback">  
                                    <label for="txtLatLong"> <font color="#282828"> Latitud y Longitud: </font></label>
                                    <input type="input" class="form-control" id="txtLatLong" placeholder="latitud,-longitud" >
                                    <i class="glyphicon glyphicon-map-marker form-control-feedback"></i>
                                </div>
                                <div class="form-group  has-feedback">
                                        <label for="txtDirecc"> <font color="#282828"> Dirección: </font></label>
                                        <textarea class="form-control" placeholder="Dirección" rows="2" id="txtDirecc" required ></textarea>
                                        <i class="  glyphicon glyphicon-list-alt form-control-feedback"></i>                                
                                </div>
                                        
                                <div class="form-group has-feedback">  
                                        <label for="txtTelefono"> <font color="#282828"> Teléfono: </font></label>
                                        <input type="input" onkeypress="return isNumberKey(event)" class="form-control" id="txtTelefono" placeholder="555353552" >
                                        <i class="glyphicon glyphicon-earphone form-control-feedback"></i>
                                </div>
            
                                <div class="form-group has-feedback">  
                                        <label for="txtCorreo"> <font color="#282828"> Correo: </font></label>
                                        <input type="input"  class="form-control" id="txtCorreo" placeholder="juanperez@ejemplo.com" >
                                        <i class=" glyphicon glyphicon-envelope form-control-feedback"></i>
                                </div>
            
                                <div class="form-group has-feedback">  
                                        <label for="txtSitio"> <font color="#282828"> Sitio Web Oficial: </font></label>
                                        <input type="input"  class="form-control" id="txtSitio" placeholder="www.tunegocio.com" >
                                        <i class="glyphicon glyphicon-globe form-control-feedback"></i>
                                </div>
                                <div class="form-group has-feedback">
                                        <label for="txtURLImagen"> <font color="#282828"> Link de Imagen de Negocio: </font></label>
                                        <input type="input"  class="form-control" id="txtURLImagen" placeholder="www.tunegocio.com/imagendeNegocio.png" >
                                        <i class="glyphicon glyphicon-picture  glyphicon-link form-control-feedback"></i>
                                </div>
                                <div class="form-group" >
                                        <div class="col-md-5">
                                            <button  type="submit" class="btn btn-primary"> Guardar Cambios </button>
                                        </div>
                                </div>
                </form>
                <?php
                        if(empty($_GET['ValidUser']))
                        {
                                
                                echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
                                echo "<script>removeDom();</script>";
                        }
                        else
                        {
                                echo $_GET['ValidUser'] . " ID : " . $_GET['id'];
                                $response  = NULL; // Json HttpSql request 
                                $fieldsObj = "isvisible:shop_registry";
                                //executeRequest Curl  query
                                $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|isvisible,shop_registry|FROM|declub_shops|WHERE|id_shop|=|%27".$_GET['id']."%27;");
                                echo "<script>loadViewData('".$response."','".$fieldsObj."')</script>";

                                
                        }


                        function executeHttpRequest($URL) {
                                
                                $curl = curl_init();
                                // Set some options - we are passing in a useragent too here
                                curl_setopt_array($curl, array(
                                    CURLOPT_RETURNTRANSFER => 1,
                                    CURLOPT_URL => $URL,
                                    CURLOPT_USERAGENT => 'deClubmx HttpRequest'
                                ));
                                // Send the request & save response to $resp
                                $resp = curl_exec($curl);
                                // Close request to clear up some resources
                                curl_close($curl);
                                return $resp;
                    
                            }
                ?> 
                
        </div> 
    </div>
<script type="text/javascript">
            function isNumberKey(evt){
                var charCode = (evt.which) ? evt.which : event.keyCode
                if (charCode > 31 && (charCode < 48 || charCode > 57))
                    return false;
                return true;
            }    
</script>
</body>
</html>