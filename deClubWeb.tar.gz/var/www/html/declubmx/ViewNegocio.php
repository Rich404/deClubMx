<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container" >
            <div class="well"> Nombre Negocio
                <br>
                    <p  class="text-success"  style="text-align:right;float:right;"> Activado <p style="text-align:right;float:right;">Status: </p> </p> 
                    <br>
                    <p  class="text-primary"  style="text-align:right;float:right;">27-Ago-2017<p style="text-align:right;float:right;"> Registro:</p> </p> 
                    <form lass="form-inline" role="form">
                            <div class="form-group">
                                <label for="txtId"> <font color="#282828"> ID: </font></label>
                                <input disabled type="input" class="form-control" id="txtId" placeholder="-*-" name="txtId">
                            </div>
                            <div class="form-group">
                                <label for="checkIsVisible"> <font color="#282828"> Activo: </font></label>
                                <input  type="checkbox" class="" checked id="checkIsVisible" name="checkIsVisible">
                            </div>
                            <div class="form-group">
                                    <label for="txtNombre"> <font color="#282828"> Nombre: </font></label>
                                    <input type="input" class="form-control" id="txtNombre" placeholder="Nombre de Negoocio" required >
                            </div>
                            <div class="form-group  has-feedback">
                                    <label for="txtDescri"> <font color="#282828"> Descripción: </font></label>
                                    <textarea class="form-control" placeholder="Describe tu Negocio" rows="2" id="txtDescri" required ></textarea>
                                    <i class="  glyphicon glyphicon-list-alt form-control-feedback"></i>                                
                            </div>
                            <!-- Ajustando dependoiendo si se agregará o modificar la categoria -->        
                            <div class="form-group">  
                                    <label for="comboCategoria"> <font color="#282828"> Categoria: </font></label>
                                    <select class="form-control" name="comboCategoria">
                                            <option>Pizzeria</option>
                                            <option>Refaccionarias</option>
                                    </select>   
                            </div>
                            <!-- Ajustando dependoiendo si se agregará o modificar la categoria --> 

                            <div class="form-group has-feedback">  
                                    <label for="txtLatLong"> <font color="#282828"> Latitud y Longitud: </font></label>
                                    <input type="input" class="form-control" id="txtLatLong" placeholder="latitud,-longitud" >
                                    <i class="glyphicon glyphicon-map-marker form-control-feedback"></i>
                                </div>
                                <div class="form-group  has-feedback">
                                        <label for="txtDirecc"> <font color="#282828"> Dirección: </font></label>
                                        <textarea class="form-control" placeholder="Dirección" rows="2" id="txtDirecc" required ></textarea>
                                        <i class="  glyphicon glyphicon-list-alt form-control-feedback"></i>                                
                                </div>
                                        
                                <div class="form-group has-feedback">  
                                        <label for="txtTelefono"> <font color="#282828"> Teléfono: </font></label>
                                        <input type="input" onkeypress="return isNumberKey(event)" class="form-control" id="txtTelefono" placeholder="555353552" >
                                        <i class="glyphicon glyphicon-earphone form-control-feedback"></i>
                                </div>
            
                                <div class="form-group has-feedback">  
                                        <label for="txtCorreo"> <font color="#282828"> Correo: </font></label>
                                        <input type="input"  class="form-control" id="txtCorreo" placeholder="juanperez@ejemplo.com" >
                                        <i class=" glyphicon glyphicon-envelope form-control-feedback"></i>
                                </div>
            
                                <div class="form-group has-feedback">  
                                        <label for="txtSitio"> <font color="#282828"> Sitio Web Oficial: </font></label>
                                        <input type="input"  class="form-control" id="txtSitio" placeholder="www.tunegocio.com" >
                                        <i class="glyphicon glyphicon-globe form-control-feedback"></i>
                                </div>
                                <div class="form-group has-feedback">
                                        <label for="txtURLImagen"> <font color="#282828"> Link de Imagen de Negocio: </font></label>
                                        <input type="input"  class="form-control" id="txtURLImagen" placeholder="www.tunegocio.com/imagendeNegocio.png" >
                                        <i class="glyphicon glyphicon-picture  glyphicon-link form-control-feedback"></i>
                                </div>
                                <div class="form-group" >
                                        <div class="col-md-5">
                                            <button  type="submit" class="btn btn-primary"> Guardar Cambios </button>
                                        </div>
                                </div>
                </form>
    
        </div>
    </div>
<script type="text/javascript">
            function isNumberKey(evt){
                var charCode = (evt.which) ? evt.which : event.keyCode
                if (charCode > 31 && (charCode < 48 || charCode > 57))
                    return false;
                return true;
            }    
</script>
</body>
</html>