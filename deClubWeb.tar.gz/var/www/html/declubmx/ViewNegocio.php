<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <script type="text/javascript">
        function removeDom()
        {
                var elem = document.getElementById("formData");
                elem.remove();
        }
        function loadViewData(JsonResponse,fieldsResponse)
        {
                var JsonData = JSON.parse(JsonResponse);
                console.log(JsonData[0]); 
                var fieldsData = fieldsResponse.split(":");
                for(var i=0;i < fieldsData.length;i++)
                {
                        console.log("Campo: " + fieldsData[i]);
                        //document.getElementById(fieldsData[i]).innerHTML = JsonData[0][fieldsData[i]];
                        //console.log("Campo: " + document.getElementById(fieldsData[i]));
                        var  domObjElment = document.getElementById(fieldsData[i])
                        console.log(domObjElment.nodeName);
                        switch(domObjElment.nodeName)
                        {
                                case "P":
                                case "H1":
                                        domObjElment.innerHTML = JsonData[0][fieldsData[i]];
                                break;
                                case "INPUT":
                                        
                                        switch (domObjElment.getAttribute("type"))
                                        {
                                                case "input":
                                                         domObjElment.value = JsonData[0][fieldsData[i]];
                                                break;
                                                
                                                case "checkbox":
                                                        console.log(JsonData[0][fieldsData[i]].replace("\"",""));
                                                        
                                                        if(JsonData[0][fieldsData[i]] == "true")
                                                        {
                                                                domObjElment.checked = true;
                                                        }
                                                        else{
                                                                domObjElment.checked = false;
                                                        }
                                                break;                                                break;
                                        }
                                        
                                break;

                        }
                        
                }       
                //console.log(JsonData[0]['isvisible']);
                

        }
    </script>     
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container" >

           <div class="well"> 
                <br>
                    <p  id="isvisible" name="isvisible" class="text-success"  style="text-align:right;float:right;"> Activado <p style="text-align:right;float:right;">Status: </p> </p> 
                    <br>
                    <p  id="shop_registry" name="shop_registry" class="text-primary"  style="text-align:right;float:right;">27-Ago-2017<p style="text-align:right;float:right;"> Registro:</p> </p> 
                    <form lass="form-inline" role="form" id="formData">
                            <div class="form-group">
                                <label for="id_shop"> <font color="#282828"> ID: </font></label>
                                <input disabled type="input" class="form-control" id="id_shop" placeholder="-*-" name="id_shop">
                            </div>
                            <div class="form-group">
                                <label for="isvisiblecheck"> <font color="#282828"> Activo: </font></label>
                                <input  type="checkbox" class="" checked id="isvisiblecheck" name="isvisiblecheck">
                            </div>
                            <div class="form-group">
                                    <label for="txtNombre"> <font color="#282828"> Nombre: </font></label>
                                    <input type="input" class="form-control" id="txtNombre" placeholder="Nombre de Negoocio" required >
                            </div>
                            <div class="form-group  has-feedback">
                                    <label for="txtDescri"> <font color="#282828"> Descripción: </font></label>
                                    <textarea class="form-control" placeholder="Describe tu Negocio" rows="2" id="txtDescri" required ></textarea>
                                    <i class="  glyphicon glyphicon-list-alt form-control-feedback"></i>                                
                            </div>

                            <div class="form-group">  
                                    <label for="comboCategoria"> <font color="#282828"> Categoria: </font></label>
                                    <select id="comboCategoria" class="form-control" name="comboCategoria">
                                            <option>Pizzeria</option>
                                            <option>Refaccionarias</option>
                                    </select>   
                            </div>
                            <div class="form-group has-feedback">  
                                    <label for="txtLatLong"> <font color="#282828"> Latitud y Longitud: </font></label>
                                    <input type="input" class="form-control" id="txtLatLong" placeholder="latitud,-longitud" >
                                    <i class="glyphicon glyphicon-map-marker form-control-feedback"></i>
                                </div>
                                <div class="form-group  has-feedback">
                                        <label for="txtDirecc"> <font color="#282828"> Dirección: </font></label>
                                        <textarea class="form-control" placeholder="Dirección" rows="2" id="txtDirecc" required ></textarea>
                                        <i class="  glyphicon glyphicon-list-alt form-control-feedback"></i>                                
                                </div>
                                        
                                <div class="form-group has-feedback">  
                                        <label for="txtTelefono"> <font color="#282828"> Teléfono: </font></label>
                                        <input type="input" onkeypress="return isNumberKey(event)" class="form-control" id="txtTelefono" placeholder="555353552" >
                                        <i class="glyphicon glyphicon-earphone form-control-feedback"></i>
                                </div>
            
                                <div class="form-group has-feedback">  
                                        <label for="txtCorreo"> <font color="#282828"> Correo: </font></label>
                                        <input type="input"  class="form-control" id="txtCorreo" placeholder="juanperez@ejemplo.com" >
                                        <i class=" glyphicon glyphicon-envelope form-control-feedback"></i>
                                </div>
            
                                <div class="form-group has-feedback">  
                                        <label for="txtSitio"> <font color="#282828"> Sitio Web Oficial: </font></label>
                                        <input type="input"  class="form-control" id="txtSitio" placeholder="www.tunegocio.com" >
                                        <i class="glyphicon glyphicon-globe form-control-feedback"></i>
                                </div>
                                <div class="form-group has-feedback">
                                        <label for="txtURLImagen"> <font color="#282828"> Link de Imagen de Negocio: </font></label>
                                        <input type="input"  class="form-control" id="txtURLImagen" placeholder="www.tunegocio.com/imagendeNegocio.png" >
                                        <i class="glyphicon glyphicon-picture  glyphicon-link form-control-feedback"></i>
                                </div>
                                <div class="form-group" >
                                        <div class="col-md-5">
                                            <button  type="submit" class="btn btn-primary"> Guardar Cambios </button>
                                        </div>
                                </div>
                </form>
                <?php
                        if(empty($_GET['ValidUser']))
                        {
                                
                                echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
                                echo "<script>removeDom();</script>";
                        }
                        else
                        {
                                echo $_GET['ValidUser'] . " ID : " . $_GET['id'];
                                $response  = NULL; // Json HttpSql request 
                                $fieldsObj = "isvisible:shop_registry:id_shop:isvisiblecheck";
                                //executeRequest Curl  query
                                $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|shop_registry,CASE|WHEN|CAST%28isvisible|AS|CHAR%29|=|%271%27|THEN|%27Activo%27|ELSE|%27Inactivo%27|END|AS|isvisible,id_shop,CASE|WHEN|CAST%28isvisible|AS|CHAR%29|=|%271%27|THEN|%27true%27|ELSE|%27false%27|END|AS|isvisiblecheck|FROM|declub_shops|WHERE|id_shop=%27".$_GET['id']."%27;");

                                echo "<script>loadViewData('".$response."','".$fieldsObj."')</script>";

                                
                        }


                        function executeHttpRequest($URL) {
                                
                                $curl = curl_init();
                                // Set some options - we are passing in a useragent too here
                                curl_setopt_array($curl, array(
                                    CURLOPT_RETURNTRANSFER => 1,
                                    CURLOPT_URL => $URL,
                                    CURLOPT_USERAGENT => 'deClubmx HttpRequest'
                                ));
                                // Send the request & save response to $resp
                                $resp = curl_exec($curl);
                                // Close request to clear up some resources
                                curl_close($curl);
                                return $resp;
                    
                            }
                ?> 
                
        </div> 
    </div>
<script type="text/javascript">
            function isNumberKey(evt){
                var charCode = (evt.which) ? evt.which : event.keyCode
                if (charCode > 31 && (charCode < 48 || charCode > 57))
                    return false;
                return true;
            }    
</script>
</body>
</html>