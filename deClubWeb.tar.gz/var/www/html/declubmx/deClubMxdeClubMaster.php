<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>  
<body style="background-color:#24384C;">  
<?php

    if(empty($_GET['ValidUser']))
    {
      // no se puede continuar con l¿el manu, es posible que se esté intente accesar sin credenciales
      echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
      
    }
    else
    {
        // El usuario es valido y se puede continuar con el menú
        echo "<nav class=\"navbar navbar-inverse\">
        <div class=\"container-fluid\">
          <div class=\"navbar-header\">
            <a class=\"navbar-brand\" href=\"#\">deClubMx</a>
          </div>
          <ul class=\"nav navbar-nav \">
            <li id=\"linkNegocios\" class=\"active\"><a onclick=\"changeIframe('Negocios')\" >Negocios</a></li>
            <li id=\"linkDatos\" class=\"\" ><a  onclick=\"changeIframe('AppAdmin')\" >AppAdmin</a></li>
            <li id=\"linkPagos\" class=\"\" ><a onclick=\"changeIframe('deClubUsuarios')\" >Usuarios</a></li>
          </ul>
          <ul class=\"nav navbar-nav navbar-right\">
            <li><a href=\"#\"><span class=\"glyphicon glyphicon-log-in\"></span> Salir</a></li><!-- La idea es elimina una cookie-->
          </ul>
        </div>
      </nav>
      <div class=\"embed-responsive embed-responsive-16by9\">
              <iframe id='masterIframe'class=\"embed-responsive-item\" src=\"AdminNegocios.php?ValidUser=".$_GET['ValidUser']."\" allowfullscreen ></iframe>
      </div>
      <script type=\"text/javascript\">
              function changeIframe(lsIFrameName)
              {  
          switch(lsIFrameName)
          {
            case 'Negocios':
              document.getElementById(\"linkNegocios\").classList.add('active');
              document.getElementById(\"linkDatos\").classList.remove('active');
              document.getElementById(\"linkPagos\").classList.remove('active');
              document.getElementById('masterIframe').src = 'AdminNegocios.php?ValidUser=".$_GET['ValidUser']."';

            break;
      
            case 'AppAdmin':
              document.getElementById(\"linkDatos\").classList.add('active');
              document.getElementById(\"linkNegocios\").classList.remove('active');
              document.getElementById(\"linkPagos\").classList.remove('active');
              document.getElementById('masterIframe').src = 'ConfigApp.php?ValidUser=".$_GET['ValidUser']."';
            break;
      
            case 'deClubUsuarios':
              document.getElementById(\"linkPagos\").classList.add('active');
              document.getElementById(\"linkDatos\").classList.remove('active');
              document.getElementById(\"linkNegocios\").classList.remove('active');
              document.getElementById('masterIframe').src = 'ViewUsers.php?ValidUser=".$_GET['ValidUser']."';
            break;
      
          }
              }
      </script>";
        
    }
    
?>
</body>
</html>