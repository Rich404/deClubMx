<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <style>
    img {
        height:50px;
        width:10%;
    }
    </style> 
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container" >
        <div class="well"> <h1>Slider App</h1>
            <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>ID SliderImage</th>
                        <th>ID Negocio</th>
                        <th>URL de Imagen</th>
                        <th>Accíon</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>1</td>
                        <td><input type="text" class="form-control" id="" value="CopTIMESTAMP"></td>
                        <td><img src="https://i1.wp.com/www.dondeir.com/wp-content/uploads/2017/03/buffet-de-pizzas-en-cdmx-como-todo-que-puedas-por-149-pesos-3.jpg?ssl=1" alt="..." class=""></td>
                        <td><button type="button" class="btn btn-primary">Guardar Cambios</button></td>                
                    </tr>
                    <tr>
                            <td>2</td>
                            <td><input type="text" class="form-control" id="" value="CopTIMESTAMP"></td>
                            <td><img src="https://i1.wp.com/www.dondeir.com/wp-content/uploads/2017/01/ruta-gastronomica-italiana-c.jpg?ssl=1" alt="..." class=""></td>
                            <td><button type="button" class="btn btn-primary">Guardar Cambios</button></td>                
                        </tr>
                    </tbody>
                </table>   
        </div>
        <div class="well"> <h1>Categorías</h1>
            <label class="col-sm-1" for="txtCateg"> Nombre: </label>
            <div class="col-sm-2 pull-left">
                <input class="form-control" id="txtCateg" type="text"> 
            </div>
            <div class="pull-left">
                   <button  onclick="" type="button" class="btn btn-primary"> Añadir Nueva Categoría </button> 
            </div>
            <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>ID Categoría</th>
                        <th>Categoría</th>
                        <th>Accíon</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>1</td>
                        <td>Escuelas</td>
                        <td><button type="button" class="btn btn-danger">Eliminar</button></td>                
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Panaderias</td>
                        <td><button type="button" class="btn btn-danger">Eliminar</button></td>            
                    </tr>
                    </tbody>
                </table>
        </div>
    </div>
<script type="text/javascript">
            function isNumberKey(evt){
                var charCode = (evt.which) ? evt.which : event.keyCode
                if (charCode > 31 && (charCode < 48 || charCode > 57))
                    return false;
                return true;
            }    
</script>
</body>
</html>