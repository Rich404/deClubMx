<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <script type="text/javascript">
        function removeDom()
        {
                var elem = [];
                elem[0] = document.getElementById("divSlider");
                elem[0].remove();

                elem[1] = document.getElementById("divCategories");
                elem[1].remove();
        }
        function insertData(arrayData,table)
        {
            var arrayValues = [];
            arrayValues[0] = document.getElementById(arrayData[0]).value;
            if(arrayValues[0] != "")
            {
                if(arrayData.length > 1)
                {
                    executeHttpRequest("INSERT|INTO|"+table+"|("+arrayData[0]+","+arrayData[1]+")|VALUES|(%27"+arrayValues[0]+"%27,%27%27);");           
                }
                else
                {
                    executeHttpRequest("INSERT|INTO|"+table+"|("+arrayData[0]+")|VALUES|(%27"+arrayValues[0]+"%27);");
           
                }
            }
            else
            {
                alert("Por favor llene el campo.");
            }

        }
        function deleteData(dataProcess,domElementButton)
        {
                var DataBC = dataProcess.split("^");

                var domElemntTR = domElementButton.parentElement.parentElement;
                var selectedIndex =  domElemntTR.rowIndex;
                var selectdData = document.getElementById(DataBC[0]).rows[selectedIndex].cells[0].innerHTML;
        
                //console.log("DELETE FROM " + DataBC[0] + " WHERE " + DataBC[1] +"="+ selectdData);
                executeHttpRequest("DELETE|FROM|" + DataBC[0] + "|WHERE|" + DataBC[1] +"|=|"+ selectdData);

        }
        function executeHttpRequest(sqlBatch) {


            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {

                    var jsonResponse = JSON.parse(xhttp.responseText); 
                    console.log(jsonResponse[0].batch_status);
                    if(jsonResponse[0].batch_status != '0')
                    {
                        alert(" Ha ocurrido un error al hacer la petición al servidor: " + jsonResponse[0].batch_status );
                    }
                    else
                    {
                        alert(" Se han guardado los cambios  Status:" + jsonResponse[0].batch_status );
                            
                    }
                    location.reload();    
                }
            };
            xhttp.open("GET", "http://localhost/declubmx/executeCommand.php?query="+ sqlBatch, true);
            xhttp.send();
            
        }
        function processView(DATA,tableId) {
        
        
        var Objtable = document.getElementById(tableId); // var Objtable = document.getElementById("tableResult").getElementsByTagName('tbody')[0];
        var rowPosition = Objtable.insertRow(Objtable.rows.length);
        var FieldsCount =  Objtable.rows[0].cells.length;
        var Fields = [];
        for(i = 0; i < FieldsCount; i++)
        {
            Fields[i] = rowPosition.insertCell(i);
           
        }
       
        var DataBP = DATA.split("|");
        for (i = 0; i < DataBP.length-1; i++) {// DataBP.length-1 se debe a que el,String trae un  "|" extra y split de lo cuenta como un item más. 
           
            var DataBTP = DataBP[i].split(":");
            switch (DataBTP[0]) {
                case 'text':
                    Fields[i].innerHTML = DataBTP[2];
                break;
                case 'button':
                    Fields[i].innerHTML =  "<button type=\"button\" onclick=\"deleteData('"+DataBTP[2]+"',this)\"  class=\"btn  btn-"+DataBTP[3]+"\"> "+DataBTP[1]+" </button>";
                break;
                case 'image':
                        Fields[i].innerHTML = "<img  src=\""+ DataBTP[3] +"\" alt=\"...\" class=\"\">";

                break;
            }

            
        }

    }
    </script>
    <style>
    img {
        height:50px;
        width:10%;
    }
    </style> 
</head>  
<body style="background-color:#24384C;">
 
	<br>
    <div class="container" >
        <div class="well" id="divSlider" > <h1>Slider App</h1>
        <label class="col-sm-1" for="id_shop">Id Negocio: </label>
            <div class="col-sm-2 pull-left">
                <input class="form-control" id="id_shop" type="text"> 
            </div>
            <div class="pull-left">
                   <button  onclick="insertData(['id_shop'],'declub_slider_images');" type="button" class="btn btn-primary"> Añadir Nuevo Item </button> 
            </div> 
            <table class="table table-hover" id="declub_slider_images">
                    <thead>
                    <tr>
                        <th>ID Slider</th>
                        <th>Negocio</th>
                        <th>URL de Imagen</th>
                        <th>Accíon</th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>   
        </div>
        <div class="well" id="divCategories"> <h1>Categorías</h1>
            <label class="col-sm-1" for="description_category"> Nombre: </label>
            <div class="col-sm-2 pull-left">
                <input class="form-control" id="description_category" type="text"> 
            </div>
            <div class="pull-left">
                   <button  onclick="insertData(['description_category','url_image_category'],'declub_categories');" type="button" class="btn btn-primary"> Añadir Nueva Categoría </button> 
            </div>
            <table class="table table-hover" id="declub_categories">
                    <thead>
                    <tr>
                        <th>ID Categoría</th>
                        <th>Categoría</th>
                        <th>Accíon</th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
        </div>
        <?php
            
            if(empty($_GET['ValidUser']))
            {
                echo " <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
                echo "<script>removeDom();</script>";    
            }
            else
            {
                $response  = NULL;
                //OjbView sitax: type:value:config   (config) configuración de campo puede ser, algun un color o tamaño para un elemento, etc.          
                $fields = array("text:id_image:none","text:shop_name:none","image:shop_url_image:none","button:Eliminar:danger"); 
                $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|declub_slider_images.id_image,declub_shops.shop_name,declub_shops.shop_url_image,%27declub_slider_images%5Eid_image%27|AS|Eliminar|FROM|declub_slider_images|INNER|JOIN|declub_shops|ON|declub_slider_images.id_shop||=|declub_shops.id_shop;");
                
                $response_decoded = json_decode($response,true);
                
                for($i = 0; $i < count($response_decoded); ++$i) {
                    
                    $DataForResult = NULL;
                    
                    for($j=0;$j<count($fields);$j++)
                    {
                        $ValueFields = NULL;
                        $ValueFields = split(":", $fields[$j]);
                        //echo   "<br>" . $response_decoded[$i][$ValueFields[1]];
                        //                  Tipo de Field      Nombre del Field     Valor de Field from decodedJsonArray     Property        
                        $DataForResult .=  $ValueFields[0].":".$ValueFields[1].":".$response_decoded[$i][$ValueFields[1]].":".$ValueFields[2]."|";
    
                    }
                    echo "<script>processView('". $DataForResult ."','declub_slider_images');</script>";
                     
                }

                $response  = NULL;
                //OjbView sitax: type:value:config   (config) configuración de campo puede ser, algun un color o tamaño para un elemento, etc.          
                $fields = array("text:id_category:none","text:description_category:none","button:Eliminar:danger"); 
                
                $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|id_category,description_category,%27declub_categories%5Eid_category%27|AS|Eliminar|FROM|declub_categories|WHERE|url_image_category|IS|NOT|NULL;");
                
                $response_decoded = json_decode($response,true);
                
                for($i = 0; $i < count($response_decoded); ++$i) {
                    
                    $DataForResult = NULL;
                    
                    for($j=0;$j<count($fields);$j++)
                    {
                        $ValueFields = NULL;
                        $ValueFields = split(":", $fields[$j]);
                        //echo   "<br>" . $response_decoded[$i][$ValueFields[1]];
                        //                  Tipo de Field      Nombre del Field     Valor de Field from decodedJsonArray     Property        
                        $DataForResult .=  $ValueFields[0].":".$ValueFields[1].":".$response_decoded[$i][$ValueFields[1]].":".$ValueFields[2]."|";
    
                    }
                    //echo "<br>" . $DataForResult;
                    echo "<script>processView('". $DataForResult ."','declub_categories');</script>";
                     
                }


            }
            function executeHttpRequest($URL) {
                
                $curl = curl_init();
                // Set some options - we are passing in a useragent too here
                curl_setopt_array($curl, array(
                    CURLOPT_RETURNTRANSFER => 1,
                    CURLOPT_URL => $URL,
                    CURLOPT_USERAGENT => 'deClubmx HttpRequest'
                ));
                // Send the request & save response to $resp
                $resp = curl_exec($curl);
                // Close request to clear up some resources
                curl_close($curl);
                return $resp;
    
            }
        ?> 
    </div>
<script type="text/javascript">
            function isNumberKey(evt){
                var charCode = (evt.which) ? evt.which : event.keyCode
                if (charCode > 31 && (charCode < 48 || charCode > 57))
                    return false;
                return true;
            }    
</script>
</body>
</html>