<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <style>
        .table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
          background-color: #AFAFAF;
        }
    </style> 
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container" >
        <div class="well">
    <h2>Pagos</h2>
    <table class="table table-hover">
        <thead>
        <tr>
            <th>ID Pago</th>
            <th>Negocio</th>
            <th>Mes</th>
            <th>Estatus de Pago</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>1</td>
            <td>Pizza Hut</td>
            <td>Diciembre</td>
            <td><p class="text-success">Pagado</p></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Pizza TU GFA</td>
            <td>Agosto</td>
            <td><p class="text-muted">Sin Pago</p></td>
        </tr>
        </tbody>
    </table>
</div>
    </div>
<script type="text/javascript">
</script>
</body>
</html>