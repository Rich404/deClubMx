<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container" >
        <div class="well"> <h4> Datos de Acceso </h4> 
                <br>
            <form class="form-horizontal" action="" method="POST" >
                    <div class="form-group has-feedback ">  
                            <label for="txtOldPassword"> <font color="#282828"> Password Actual:  </font></label>
                            <input type="password" class="form-control" id="txtOldPassword" placeholder="Contraseña Actual" required  >
                            <i class="glyphicon glyphicon-pencil form-control-feedback"></i>
                    </div>
                    <div class="form-group has-feedback ">  
                            <label for="txtNewPassword"> <font color="#282828">  Nuevo Password:  </font></label>
                            <input type="password" class="form-control" id="txtNewPassword" placeholder="Nueva Contraseña" required  >
                            <i class="glyphicon glyphicon-pencil form-control-feedback"></i>
                    </div>
                    <div class="form-group" >
                            <div class="col-md-5 text-center">
                                 <button  type="submit" class="btn btn-primary"> Guardar Cambios </button>
                            </div>
                        </div>

            </form>
        </div>
        <div class="well"> <h4> Datos Generales  </h4>
                <br>
                <form class="form-horizontal" action="" method="POST" >
                        <div class="form-group" >  <!---- Ajustar tamaño de text -->
                            <label class="control-label col-sm-2" for="lblNombre">  Nombre:  </label>
                                  <div class="col-sm-2">
                                    <input class="form-control" placeholder="Nombres" name="txtNombre" type="text" required > 
                                  </div>
                          </div>
              
                          <div class="form-group " >  <!---- Ajustar tamaño de text -->
                            <label class="control-label col-sm-2" for="lblNombre">  Apellidos:   </label>
                                  <div class="col-sm-4">
                                    <input class="form-control"  placeholder="Apellidos" name="txtApellidos" type="text" required > 
                                  </div>
                          </div>
                          
                          <div class="form-group " >  <!---- Ajustar tamaño de text -->
                            <label class="control-label col-sm-2" for="lblNombre">  Email:  </label>
                                  <div class="col-sm-4">
                                    <input class="form-control"  placeholder="ejemplo@dominio.com" name="txtEmail" type="text" required > 
                                  </div>
                          </div>
                          <div class="form-group " >  <!---- Ajustar tamaño de text -->
                            <label class="control-label col-sm-2" for="lblNombre"> Teléfono:   </label>
                                  <div class="col-sm-2">
                                    <input class="form-control"  placeholder="555355.." name="txtTel" type="text" required > 
                                  </div>
                          </div>
              
                          <div class="form-group " >  <!---- Ajustar tamaño de text -->
                            <label class="control-label col-sm-2" for="lblDomicilio">  Domicilio:  </label>
                                  <div class="col-sm-4">
                                    <textarea class="form-control" placeholder="Calle  X #37, Colonia Z Estado ó Ciudad" rows="3" name="txtDomicilio" required ></textarea>
                                  </div>	
                           </div>
                           <div class="form-group" >
                               <div class="col-md-5 text-center">
                                    <button  type="submit" class="btn btn-primary"> Guardar Cambios </button>
                               </div>
                           </div>
                </form>

        </div>
    </div>
<script type="text/javascript">
</script>
</body>
</html>