<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
  <script type="text/javascript">
    function removeDom()
        {
                var elem = document.getElementById("masterDiv");
                elem.remove();
        }
        function loadViewData(JsonResponse,fieldsResponse)
        {
                console.log(JsonResponse);
                if(JsonResponse != "[]")
                {
                        var JsonData = JSON.parse(JsonResponse);
                        var fieldsData = fieldsResponse.split(":");
                        for(var i=0;i < fieldsData.length;i++)
                        {
                                
                                var  domObjElment = document.getElementById(fieldsData[i])
                                switch(domObjElment.nodeName)
                                {
                                        case "P":
                                        case "H1":
                                                domObjElment.innerHTML = JsonData[0][fieldsData[i]];
                                        break;
                                        case "INPUT":
                                                domObjElment.value = JsonData[0][fieldsData[i]];
                                              
                                        break;
                                        case "TEXTAREA":
                                                domObjElment.value = JsonData[0][fieldsData[i]];
                                        break;

                                        case "SELECT":
                                        
                                                var domObjElmentOption = document.getElementById(fieldsData[i]);
                                                var elementOption = document.createElement("option");
                                                elementOption.text = JsonData[fieldsData[i]] ;
                                                domObjElmentOption.add(elementOption);

                                        break;
                                                
                                } 
                                
                        }         
                }
                else
                {
                        //var elem = document.getElementById("formData");
                        //elem.remove();
                }
                

        }
        function saveData(type)
        {
                
                var oldpass = document.getElementById("txtpassword").value
                var newpass = document.getElementById("txtNewPassword").value

                if(type == "UserAcces" && oldpass != "" && newpass != "" && newpass.length >= 8)
                {
                        
                        executeHttpRequest("SELECT|COUNT%28*%29|AS|result|FROM|declub_users|WHERE|user_id|=|%27"+ document.getElementById("user_id").value +"%27|AND|user_password|=|%27"+ document.getElementById("txtpassword").value +"%27;","txtpassword");
                         if(document.getElementById("txtpassword").disabled == true)
                         {
                                executeHttpRequestBatch("UPDATE|declub_users|SET|user_password|=|%27admin%27|WHERE|user_id|=|%27"+  newpass +"%27;");
                         }
                         
                }
                else if(type == "UserInfo")
                {
                        executeHttpRequestBatch("UPDATE|declub_userinfo|SET|name|=|%27"+ document.getElementById("name").value +"%27,address|=|%27"+ document.getElementById("address").value +"%27,phone|=|%27"+ document.getElementById("phone").value +"%27,mail|=|%27"+ document.getElementById("mail").value +"%27|WHERE|user_id|=|%27"+ document.getElementById("user_id").value +"%27;");
                }
                else
                {
                        alert("Por favor llene los campos. (Password 8 caracteres como minimo)");
                }
                

        }
        function executeHttpRequest(sqlQuery,id) {

            var response = null;    
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    
                    var jsonResponse = JSON.parse(xhttp.responseText); 
                    if(jsonResponse[0].result != '0')
                    {
                        
                        //alert(" Ha ocurrido un error al hacer la petición al servidor: " + jsonResponse[0].batch_status );
                        document.getElementById(id).disabled = true;
                    }
                    else
                    {
                        alert(" La contraseña ingresada no corresponde a la anterior ");
                            
                    }    
                }
            };
            xhttp.open("GET", "http://localhost/declubmx/executeQuery.php?query="+ sqlQuery, true);
            xhttp.send();
        }
        function executeHttpRequestBatch(sqlBatch) {


            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {

                    var jsonResponse = JSON.parse(xhttp.responseText); 
                    console.log(jsonResponse[0].batch_status);
                    if(jsonResponse[0].batch_status != '0')
                    {
                        alert(" Ha ocurrido un error al hacer la petición al servidor: " + jsonResponse[0].batch_status );
                    }
                    else
                    {
                        alert(" Se han guardado los cambios  Status:" + jsonResponse[0].batch_status );
                            
                    }
                    location.reload();    
                }
            };
            xhttp.open("GET", "http://localhost/declubmx/executeCommand.php?query="+ sqlBatch, true);
            xhttp.send();
            
        }
  </script>
</head>  
<body style="background-color:#24384C;">  
	<br>

    <div  id="masterDiv" class="container" >
        <div class="well"> <h4> Datos de Acceso </h4> 
                <br>
            <form class="form-horizontal" action="" method="POST" >


                    <div class="form-group has-feedback ">  
                            <label for="user_id"> <font color="#282828"> ID:  </font></label>
                            <input type="text" disabled class="form-control" id="user_id" placeholder=  "*" required  >
                    </div>
                    

                    <div class="form-group has-feedback ">  
                            <label for="txtpassword"> <font color="#282828"> Password Actual:  </font></label>
                            <input type="password" class="form-control" id="txtpassword" placeholder="Contraseña Actual" required  >
                            <i class="glyphicon glyphicon-pencil form-control-feedback"></i>
                    </div>
                    <div class="form-group has-feedback ">  
                            <label for="txtNewPassword"> <font color="#282828">  Nuevo Password:  </font></label>
                            <input type="password" class="form-control" id="txtNewPassword" placeholder="Nueva Contraseña" required  >
                            <i class="glyphicon glyphicon-pencil form-control-feedback"></i>
                    </div>
                    <div class="form-group" >
                            <div class="col-md-5 text-center">
                                 <button  onclick="saveData('UserAcces');" type="button" class="btn btn-primary"> Guardar Cambios </button>
                            </div>
                        </div>

            </form>
        </div>
        <div class="well"> <h4> Datos Generales  </h4>
                <br>
                <form class="form-horizontal" action="" method="POST" >
                          <div class="form-group has-feedback" >  <!---- Ajustar tamaño de text -->
                            <label  for="name">  Nombre:  </label>
                            <input class="form-control" placeholder="Nombres" id="name" type="text" required >
                            <i class="glyphicon glyphicon-pencil form-control-feedback"></i>
                          </div>
              
                          <div class="form-group has-feedback" >  <!---- Ajustar tamaño de text -->
                              <label  for="mail">  Email:  </label>
                              <input class="form-control"  placeholder="ejemplo@dominio.com" id="mail" type="text" required >     
                              <i class=" glyphicon glyphicon-envelope form-control-feedback"></i>
                          </div>
                          <div class="form-group has-feedback" >  <!---- Ajustar tamaño de text -->
                              <label  forform-group has-feedback> Teléfono:   </label>
                              <input class="form-control"  placeholder="555355.." id="phone" type="text" required >
                              <i class="glyphicon glyphicon-earphone form-control-feedback"></i>
                          </div>
              
                          <div class="form-group has-feedback" >  <!---- Ajustar tamaño de text -->
                              <label  for="address">  Domicilio:  </label>
                              <textarea class="form-control" placeholder="Calle  X #37, Colonia Z Estado ó Ciudad" rows="3" id="address" required ></textarea>
                              <i class="glyphicon glyphicon-pencil form-control-feedback"></i>	
                           </div>
                           <div class="form-group" >
                               <div class="col-md-5 text-center">
                                    <button  type="button" onclick="saveData('UserInfo');" class="btn btn-primary"> Guardar Cambios </button>
                               </div>
                           </div>
                </form>

        </div>
    </div>
    <?php 
                  
                  if(empty($_GET['ValidUser']) == true)
                  {
                    echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
                    echo "<script>removeDom();</script>";
                  }
                  else{
                    
                    //echo $_GET['ValidUser'];
                    $response  = NULL; // Json HttpSql request 
                    $fieldsObj = "user_id:name:mail:phone:address";
                    
                    $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|declub_users.user_id,declub_userinfo.name,declub_userinfo.mail,declub_userinfo.phone,declub_userinfo.address|FROM|declub_users|INNER|JOIN|declub_userinfo|ON|declub_users.user_id|=|declub_userinfo.user_id|WHERE|declub_users.user_id|=|%27".$_GET['ValidUser']."%27;");
                    //echo $response;
                    
                    echo "<script>loadViewData('".$response."','".$fieldsObj."')</script>";

                  }

                  function executeHttpRequest($URL) {
                    
                    $curl = curl_init();
                    // Set some options - we are passing in a useragent too here
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => $URL,
                        CURLOPT_USERAGENT => 'deClubmx HttpRequest'
                    ));
                    // Send the request & save response to $resp
                    $resp = curl_exec($curl);
                    // Close request to clear up some resources
                    curl_close($curl);
                    return $resp;
        
                }
    ?>
<script type="text/javascript">
</script>
</body>
</html>