<!--
    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *
    *   Desarrollado por : Ricardo Camacho Tenorio  Año: 2018   *   
    *   Contacto : ricardo.camacho.info@gmail.com               *
    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *
-->
<html lang="es">
<head>  
    <meta charset="UTF-8">
    <title> Acceso - Control Escolar </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>
<body onload="notBack();">
<center>
<div class="container">

<?php
	$DATA_INSERT[0] = $_POST["txtNombre"];
	$DATA_INSERT[1] = $_POST["txtApellidos"];
	$DATA_INSERT[2] = $_POST["txtEmail"];
	$DATA_INSERT[3] = $_POST["txtTel"];
	$DATA_INSERT[4] = $_POST["txtDomicilio"];
	
	/*foreach ($DATA_INSERT as $key => $val) {
		echo $val . "<br>";
	} */
	$Rnd = rand();
	$subRnd = substr($Rnd,0,3) . substr($DATA_INSERT[0],0,3) .date("m-y");
	$password =  $subRnd;
	$user =  substr($DATA_INSERT[0],0,2) . substr($DATA_INSERT[1],0,2) .substr($Rnd,0,2);
	
	$CONEXION = mysqli_connect("localhost","root","admin","declubmx_app_maintenance");
		if (mysqli_connect_errno())
			{
				echo "Error en la Conexion: \n" . mysqli_connect_error();
			}
		else
			{
				echo "<br><br>Exito en conexion<br>";	
			}
				
	$sql_insert = "INSERT INTO  declub_users (user_id,user_password,user_type,isVisible) VALUES ('".$user."','".$password."','MiNegocio',false)";
			if (mysqli_query($CONEXION, $sql_insert)) 
				{
					$sql_insert = "INSERT INTO declub_userinfo VALUES ('".$user."','". $DATA_INSERT[0] ." " .$DATA_INSERT[1] ."','".$DATA_INSERT[4]."','".$DATA_INSERT[3]."','".$DATA_INSERT[2]."')";
					if (mysqli_query($CONEXION, $sql_insert)) 
					{
						echo "<br><p>Se ha insertado un nuevo Registro</p>";
						echo "<button  onclick=\"CLOSE()\" type=\"submit\" class=\"btn btn-success\"  > Aceptar </button>";
						//sendEmail();
					}
					else 
					{
						echo "Error: " . $sql_insert . "<br>" . mysqli_error($CONEXION);
						echo "<button  onclick=\"CLOSE()\" type=\"submit\" class=\"btn btn-danger\"  > Aceptar </button>";
					}
	
				} 
			else 
				{
					echo "Error: " . $sql_insert . "<br>" . mysqli_error($CONEXION);
					echo "<button  onclick=\"CLOSE()\" type=\"submit\" class=\"btn btn-danger\"  > Aceptar </button>";
				}

	mysqli_close($CONEXION);

	function sendEmail() {
		echo "hola";
		mail("richie_camten@hotmail.com,richcuatrocuerdas@gmail.com","asuntillo","Este es el cuerpo del mensaje");
	}
?>
<script type="text/javascript">
	function CLOSE()
	{
		window.close();
	}
	function notBack()
	{

		window.location.hash="no-back-button";
   		window.location.hash="Again-No-back-button"
   		window.onhashchange=function(){window.location.hash="no-back-button";}

	}
</script>
</div>
</center>
</body>
</html>