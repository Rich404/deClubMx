<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <script type="text/javascript">
    function loadViewData(JsonResponse,fieldsResponse)
        {
                console.log(JsonResponse);
                if(JsonResponse != "[]")
                {
                        var JsonData = JSON.parse(JsonResponse);
                        var fieldsData = fieldsResponse.split(":");
                        for(var i=0;i < fieldsData.length;i++)
                        {
                                
                                var  domObjElment = document.getElementById(fieldsData[i])
                                switch(domObjElment.nodeName)
                                {
                                        case "P":
                                        case "H1":
                                                domObjElment.innerHTML = JsonData[0][fieldsData[i]];
                                        break;
                                        case "INPUT":
                                                
                                                switch (domObjElment.getAttribute("type"))
                                                {
                                                        case "input":
                                                                domObjElment.value = JsonData[0][fieldsData[i]];
                                                        break;
                                                        
                                                        case "checkbox":
                                                                
                                                                if(JsonData[0][fieldsData[i]] == "true")
                                                                {
                                                                        domObjElment.checked = true;
                                                                }
                                                                else{
                                                                        domObjElment.checked = false;
                                                                }
                                                        break;
                                                }
                                                
                                        break;
                                        case "TEXTAREA":
                                                domObjElment.value = JsonData[0][fieldsData[i]];
                                        break;

                                        case "SELECT":
                                        
                                                var domObjElmentOption = document.getElementById(fieldsData[i]);
                                                var elementOption = document.createElement("option");
                                                elementOption.text = JsonData[fieldsData[i]] ;
                                                domObjElmentOption.add(elementOption);

                                        break;
                                                
                                }
                                
                        }         
                }
                else
                {
                        //var elem = document.getElementById("formData");
                        //elem.remove();
                }
                

        }
        function removeDom()
        {
                var elem = document.getElementById("formData");
                elem.remove();
        }
        function saveData()
        {
                var domElementsArray = document.getElementsByName("InputItem");
                var arrayParameters = [];
                for (var i = 0; i < domElementsArray.length; i++) {
                        if (domElementsArray[i].getAttribute("type") == "checkbox")
                        {
                                arrayParameters[i] = domElementsArray[i].checked;

                        }
                        else
                        {
                                arrayParameters[i]  = domElementsArray[i].value;
                        }       
                }
                        //console.log(fields);
                executeHttpRequest("UPDATE|declub_shops|SET|isvisible="+arrayParameters[1]+",shop_name=%27"+arrayParameters[2]+"%27,shop_text=%27"+arrayParameters[3]+"%27,id_category=%28SELECT|id_category|FROM|declub_categories|WHERE||description_category|=|%27"+arrayParameters[4]+"%27%29,shop_latitude="+arrayParameters[5]+",shop_longitude="+arrayParameters[6]+",shop_address=%27"+arrayParameters[7]+"%27,shop_phone="+arrayParameters[8]+",shop_email=%27"+arrayParameters[9]+"%27,shop_webaddress=%27"+arrayParameters[10]+"%27,shop_url_image=%27"+arrayParameters[11]+"%27|WHERE|id_shop|=|%27"+ arrayParameters[0]+"%27;");


                
        }
        function executeHttpRequest(sqlBatch) {


            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {

                    var jsonResponse = JSON.parse(xhttp.responseText); 
                    console.log(jsonResponse[0].batch_status);
                    if(jsonResponse[0].batch_status != '0')
                    {
                        alert(" Ha ocurrido un error al hacer la petición al servidor: " + jsonResponse[0].batch_status );
                    }
                    else
                    {
                        alert(" Se han guardado los cambios  Status:" + jsonResponse[0].batch_status );
                            
                    }
                    location.reload();    
                }
            };
            xhttp.open("GET", "http://localhost/declubmx/executeCommand.php?query="+ sqlBatch, true);
            xhttp.send();
            
        }
        function changeValuesforNew(New_id_shop,NewName)
        {
                console.log(New_id_shop+":"+NewName);
                document.getElementById("id_shop").value = New_id_shop;
                document.getElementById("shop_name").value = NewName;
                document.getElementById("isvisiblecheck").checked = false;
                document.getElementById("btnAction").setAttribute("onclick", "saveNew();");
               
        }
        function saveNew()
        {
                var sql = "INSERT|INTO|declub_shops|VALUES|%28%27"+ document.getElementById("id_shop").value +"%27,%27"+document.getElementById("shop_name").value+"%27,%27"+document.getElementById("shop_text").value+"%27,"+document.getElementById("shop_latitude").value+","+document.getElementById("shop_longitude").value+",%27"+document.getElementById("shop_address").value+"%27,"+document.getElementById("shop_phone").value+",%27"+document.getElementById("shop_email").value+"%27,%27"+document.getElementById("shop_webaddress").value+"%27,0,%27"+document.getElementById("shop_url_image").value+"%27,(SELECT|id_category|FROM|declub_categories|WHERE|description_category|=|%27"+document.getElementById("description_category").value+"%27),false,(SELECT|DATE_FORMAT(NOW(),'%Y-%m-%d')),%27"+document.getElementById("ValidUser").value+"%27%29;";
                var result = sql.replace(" ","|");
                executeHttpRequest(result);
                
        }
    </script>
</head>  
<body style="background-color:#24384C;">  
	<br>
    <div class="container" >
            <div class="well">
                        <p  id="isvisible" name="" class="text-success"  style="text-align:right;float:right;">  <p style="text-align:right;float:right;">Status: </p> </p>
                        <br>
                        <p  id="shop_registry" name="" class="text-primary"  style="text-align:right;float:right;"><p style="text-align:right;float:right;"> Registro:</p> </p>
                        <form lass="form-inline" role="form" id="formData">
                                <div class="form-group">
                                    <label for="id_shop"> <font color="#282828"> ID: </font></label>
                                    <input disabled type="input" class="form-control" id="id_shop" placeholder="-*-" name="InputItem">
                                </div>
                                <div class="form-group">
                                    <label for="isvisiblecheck"> <font color="#282828"> Activo: </font></label>
                                    <input  type="checkbox" class="" disabled checked id="isvisiblecheck" name="InputItem">
                                </div>
                                <div class="form-group">
                                        <label for="shop_name"> <font color="#282828"> Nombre: </font></label>
                                        <input type="input" class="form-control" id="shop_name" name="InputItem" placeholder="Nombre de Negoocio" required >
                                </div>
                                <div class="form-group  has-feedback">
                                        <label for="shop_text"> <font color="#282828"> Descripción: </font></label>
                                        <textarea class="form-control" placeholder="Describe tu Negocio" rows="2" id="shop_text" name="InputItem" required ></textarea>
                                        <i class="  glyphicon glyphicon-list-alt form-control-feedback"></i>
                                </div>
        
                                <div class="form-group">  
                                        <label for="description_category"> <font color="#282828"> Categoria: </font></label>
                                        <select id="description_category" class="form-control" name="InputItem">
                                        </select>   
                                </div>
                                <div class="form-group has-feedback">  
                                        <label for="shop_latitude"> <font color="#282828"> Latitud: </font></label>
                                        <input type="input" class="form-control" id="shop_latitude" name="InputItem" placeholder="latitud" >
                                        <i class="glyphicon glyphicon-map-marker form-control-feedback"></i>
                                    </div>
        
                                <div class="form-group has-feedback">  
                                    <label for="shop_longitude"> <font color="#282828"> Longitud: </font></label>
                                    <input type="input" class="form-control" id="shop_longitude" name="InputItem" placeholder="-longitud" >
                                    <i class="glyphicon glyphicon-map-marker form-control-feedback"></i>
                                </div>
                            <div class="form-group  has-feedback">
                                    <label for="shop_address"> <font color="#282828"> Dirección: </font></label>
                                    <textarea class="form-control" placeholder="Dirección" rows="2" id="shop_address" name="InputItem" required ></textarea>
                                    <i class="  glyphicon glyphicon-list-alt form-control-feedback"></i>             
                            </div>
                                    
                            <div class="form-group has-feedback">  
                                    <label for="shop_phone"> <font color="#282828"> Teléfono: </font></label>
                                    <input type="input" onkeypress="return isNumberKey(event)" class="form-control" id="shop_phone" name="InputItem" placeholder="555353552" >
                                    <i class="glyphicon glyphicon-earphone form-control-feedback"></i>
                            </div>
        
                            <div class="form-group has-feedback">  
                                        <label for="shop_email"> <font color="#282828"> Correo: </font></label>
                                        <input type="input"  class="form-control" id="shop_email" name="InputItem" placeholder="juanperez@ejemplo.com" >
                                        <i class=" glyphicon glyphicon-envelope form-control-feedback"></i>
                                </div>
        
                                <div class="form-group has-feedback">
                                        <label for="shop_webaddress"> <font color="#282828"> Sitio Web Oficial: </font></label>
                                        <input type="input"  class="form-control" id="shop_webaddress" name="InputItem" placeholder="www.tunegocio.com" >
                                        <i class="glyphicon glyphicon-globe form-control-feedback"></i>
                                </div>
                                <div class="form-group has-feedback">
                                        <label for="shop_url_image"> <font color="#282828"> Link de Imagen de Negocio: </font></label>
                                        <input type="input"  class="form-control" id="shop_url_image" name="InputItem" placeholder="www.tunegocio.com/imagendeNegocio.png" >
                                        <i class="glyphicon glyphicon-picture  glyphicon-link form-control-feedback"></i>
                                </div>
                                <div class="form-group" >
                                        <div class="col-md-5">
                                                <button  id="btnAction" type="button" onclick="saveData();" class="btn btn-primary"> Guardar  </button>
                                                <!-- <button  type="button"  onclick="deleteData();" class="btn btn-danger"> Eliminar Registro </button> -->
                                        </div>
                                </div>
                        </form> 
            <?php 
                
                if(empty($_POST['ValidUser']) == false && empty($_POST['selectShop']) == false)
                {
                        $id_shop = split(" ",$_POST['selectShop']);
                        

                        $response  = NULL; // Json HttpSql request 
                        $fieldsObj = "isvisible:shop_registry:id_shop:isvisiblecheck:shop_name:shop_text:shop_latitude:shop_longitude:shop_address:shop_phone:shop_email:shop_webaddress:shop_url_image";
                        
                        $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|shop_registry,CASE|WHEN|CAST%28isvisible|AS|CHAR%29|=|%271%27|THEN|%27Activo%27|ELSE|%27Inactivo%27|END|AS|isvisible,id_shop,CASE|WHEN|CAST%28isvisible|AS|CHAR%29|=|%271%27|THEN|%27true%27|ELSE|%27false%27|END|AS|isvisiblecheck,shop_name,shop_text,shop_latitude,shop_longitude,shop_address,shop_phone,shop_email,shop_webaddress,shop_url_image|FROM|declub_shops|WHERE|id_shop=%27".$id_shop[0]."%27;");
                        
                        echo "<script>loadViewData('".$response."','".$fieldsObj."')</script>";

                        $response  = NULL; // Json HttpSql request 
                        $fieldsObj = "description_category";
                        $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|description_category|FROM|declub_categories|WHERE|id_category|=|%28SELECT|id_category|FROM|declub_shops|WHERE|id_shop||=|%27".$id_shop[0]."%27%29|UNION|SELECT|description_category|FROM|declub_categories|WHERE|url_image_category|IS|NOT|NULL;");
                        
                        $response_decoded = json_decode($response,true);
                        
                        for($i = 0; $i < count($response_decoded); ++$i) {
                                
                                echo "<script>loadViewData('".json_encode($response_decoded[$i])."','".$fieldsObj."')</script>";
                        } 
                                                        
                }
                else if(empty($_GET['ValidUser']) == false && empty($_GET['addNew']) == false)
                {
                        
                        $response  = NULL; // Json HttpSql request 
                        $fieldsObj = "description_category";
                        $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|description_category|FROM|declub_categories|WHERE|url_image_category|IS|NOT|NULL;");
                        $response_decoded = json_decode($response,true);
                        
                        for($i = 0; $i < count($response_decoded); ++$i) {
                                
                                echo "<script>loadViewData('".json_encode($response_decoded[$i])."','".$fieldsObj."')</script>";
                        } 
                        //echo $_GET['ValidUser'] . ":" . $_GET['addNew'] . ":". $_GET['id'] .":".$_GET['nameNeg'];
                        echo "<input type=\"hidden\" id=\"ValidUser\" name=\"ValidUser\" value=\"".$_GET['ValidUser']."\">";
                        echo "<script>changeValuesforNew('".$_GET['id']."','".$_GET['nameNeg']."')</script>";
                        

                        

                }
                else{
                        echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
                        echo "<script>removeDom();</script>";
                }
                function executeHttpRequest($URL) {
                        
                        $curl = curl_init();
                        // Set some options - we are passing in a useragent too here
                        curl_setopt_array($curl, array(
                            CURLOPT_RETURNTRANSFER => 1,
                            CURLOPT_URL => $URL,
                            CURLOPT_USERAGENT => 'deClubmx HttpRequest'
                        ));
                        // Send the request & save response to $resp
                        $resp = curl_exec($curl);
                        // Close request to clear up some resources
                        curl_close($curl);
                        return $resp;
            
                    }
            ?>
        </div>
    </div>
<script type="text/javascript">
            function isNumberKey(evt){
                var charCode = (evt.which) ? evt.which : event.keyCode
                if (charCode > 31 && (charCode < 48 || charCode > 57))
                    return false;
                return true;
            }    
</script>
</body>
</html>