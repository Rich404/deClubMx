<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Mi Negocio - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>  
<body style="background-color:#24384C;">  
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" >deClubMx</a>
    </div>
    <ul class="nav navbar-nav ">
      <li id="linkNegocios" class="active"><a onclick="changeIframe('AdminClient')" >Mis Negocios</a></li>
      <li id="linkDatos" class="" ><a  onclick="changeIframe('DatosCliente')" >Mis Datos</a></li>
      <li id="linkPagos" class="" ><a onclick="changeIframe('PagosCliente')" >Pagos</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Salir</a></li><!-- La idea es elimina runa cookie-->
    </ul>
  </div>
</nav>
<div class="embed-responsive embed-responsive-16by9">
        <iframe id='masterIframe'class="embed-responsive-item" src="http://localhost/declubmx/deClubMxAdminClient.php" allowfullscreen ></iframe>
</div>
<script type="text/javascript">
	function changeIframe(lsIFrameName)
	{  
    switch(lsIFrameName)
    {
      case 'AdminClient':
        document.getElementById("linkNegocios").classList.add('active');
        document.getElementById("linkDatos").classList.remove('active');
        document.getElementById("linkPagos").classList.remove('active');
        document.getElementById('masterIframe').src = 'http://localhost/declubmx/deClubMxAdminClient.php';
      break;

      case 'DatosCliente':
        document.getElementById("linkDatos").classList.add('active');
        document.getElementById("linkNegocios").classList.remove('active');
        document.getElementById("linkPagos").classList.remove('active');
        document.getElementById('masterIframe').src = 'http://localhost/declubmx/ClientInfo.php';
      break;

      case 'PagosCliente':
        document.getElementById("linkPagos").classList.add('active');
        document.getElementById("linkDatos").classList.remove('active');
        document.getElementById("linkNegocios").classList.remove('active');
        document.getElementById('masterIframe').src = 'http://localhost/declubmx/PagosCliente.php';
      break;

    }

   // alert(lsIFrameName);
    //document.getElementById('masterIframe').src = 'http://localhost/declubmx/';
	}
</script>
</body>
</html>