<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <style>
        .table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
          background-color: #AFAFAF;
        }
    </style>
    <script type="text/javascript" >
     function processView(DATA,rowIndex) {
        
        var Objtable = document.getElementById("tableResult"); // var Objtable = document.getElementById("tableResult").getElementsByTagName('tbody')[0];
        var rowPosition = Objtable.insertRow(Objtable.rows.length);
        var FieldsCount =  Objtable.rows[0].cells.length;
        var Fields = [];
        for(i = 0; i < FieldsCount; i++)
        {
            Fields[i] = rowPosition.insertCell(i);
           
        }
       
        var DataBP = DATA.split("|");
        
        rowIndex ++ ;
        for (i = 0; i < DataBP.length-1; i++) {// DataBP.length-1 se debe a que el,String trae un  "|" extra y split de lo cuenta como un item más. 
           
            var DataBTP = DataBP[i].split(":");
           
            //Fields[i].innerHTML = DataBTP[0];
            switch (DataBTP[0]) {
                case 'text':
                    Fields[i].innerHTML = DataBTP[2];
                break;
                case 'textbox':
                    Fields[i].innerHTML = "<input id=\""+DataBTP[1]+rowIndex.toString()+"\" type=\"text\" class=\"form-control\"  value=\""+DataBTP[2]+"\" disabled>";
                break;
                case 'password':
                    Fields[i].innerHTML = "<input id=\""+DataBTP[1]+rowIndex.toString()+"\" type=\"password\" class=\"form-control\"  value=\""+DataBTP[2]+"\">";
                break;
                case 'button':
                    Fields[i].innerHTML =  "<button type=\"button\" onclick=\""+DataBTP[2]+"\"  class=\"btn "+DataBTP[3]+"\"> "+DataBTP[1]+" </button>";
                break;
                case 'checkbox':
                    Fields[i].innerHTML = "<input id=\""+DataBTP[1]+rowIndex.toString()+"\" type=\"checkbox\"  "+DataBTP[2]+">";
                break;
                
            }

            
        }

    }
    function removeDom()
    {
                var elem = document.getElementById("divUsers");
                elem.remove();
    }
    function savenewUser()
    {
        var domtxtNewUser = document.getElementById("txtNewUser").value;
        if(domtxtNewUser != "" && domtxtNewUser.length > 4 )
        {
            var date =  new Date();
            var pass = prompt("Por favor ingrese una contraseña de mínimo  8 caracteres ( a continuación una contraseña por defecto ):", domtxtNewUser.substring(0,3) + date.getMinutes() + "dmx"  +  date.getSeconds());
            if (pass == null || pass == "" || pass.length < 8 ) {
                alert("No se ha podido validar el password del nuevo usuario.");
            } else {
                executeHttpRequest("INSERT|INTO|declub_users|%28user_id,|user_password,user_type,isVisible%29|VALUES|%28%27"+domtxtNewUser+"%27,%27"+pass+"%27,%27deClubMaster%27,1%29;");
            }
        }

    }
    function executeHttpRequest(sqlBatch) {


            //console.log(arrayParameters[0]);
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {

                    var jsonResponse = JSON.parse(xhttp.responseText); 
                    console.log(jsonResponse[0].batch_status);
                    if(jsonResponse[0].batch_status != '0')
                    {
                        alert(" Ha ocurrido un error al hacer la petición al servidor: " + jsonResponse[0].batch_status );
                    }
                    location.reload();    
                }
            };
            xhttp.open("GET", "http://localhost/declubmx/executeCommand.php?query="+sqlBatch, true);
            xhttp.send();
            
        }
        function execDel(domElmentButton)
        {   

            var domElemntTR = domElmentButton.parentElement.parentElement;
            var selectedIndex =  domElemntTR.rowIndex;
            var selectdData = null;
            for(var i=0;i<=3;i++)
            { selectdData += document.getElementById("tableResult").rows[selectedIndex].cells[i].innerHTML;  }
            
            //console.log(selectdData);
                /*Parse HTML String */
            /*var el = document.createElement( 'html' );
            el.innerHTML = selectdData;
            var x = el.getElementsByTagName( 'INPUT' )[0].value; 
            console.log(x); */
            var elementDom = document.createElement( 'html' );
            elementDom.innerHTML = selectdData;
            if(confirmExecuteBatch("Se eliminarán todos los datos asociados , ¿ Está seguro de continuar ? ") == true)
            {
                executeHttpRequest("DELETE|FROM|declub_users|WHERE|user_id|=|%27"+ elementDom.getElementsByTagName( 'INPUT' )[0].value + "%27;");
            }
                
        }
        function execUpd(domElmentButton)
        {
            var domElemntTR = domElmentButton.parentElement.parentElement;
            var selectedIndex =  domElemntTR.rowIndex;
            if(document.getElementById("user_password"+selectedIndex.toString()).value.length >= 8)
            {   
                if(confirmExecuteBatch("Se actualizará información asociada a accesos , ¿ Está seguro de continuar ? . ") == true)
                { 
                    executeHttpRequest("UPDATE|declub_users|SET|user_password=%27"+document.getElementById("user_password"+selectedIndex.toString()).value+"%27,isVisible="+document.getElementById("isvisible"+selectedIndex.toString()).checked+"|WHERE|user_id|=|%27"+document.getElementById("user_id"+selectedIndex.toString()).value+"%27;");
                }else{location.reload();} 
            }
            else
            {
                alert("No se ha podido validar el password. ");
                
            }
        }
        function confirmExecuteBatch(message)
        {
            var response = confirm(message);
            if (response == true) {
                return true;
            } else {
                return false;
            }
        }
</script> 
</head>  
<body style="background-color:#24384C;">  
<br>
<div class="container" >
        <div class="well" id="divUsers">
        
            <h2>Control de Usuarios</h2>
            <label class="col-sm-1" for="txtNewUser"> Usuario: </label>
            <div class="col-sm-2 pull-left">
                <input class="form-control" id="txtNewUser" placeholder="5 caracteres mínimo ." type="text"> 
            </div>
            <div class="pull-left">
                   <button  onclick="savenewUser()" type="button" class="btn btn-primary"> Añadir Nuevo Usuario </button> 
            </div>
            <table class="table table-hover" id="tableResult">
            <thead>
            <tr>
                <th>Usuario Id</th>
                <th>Password</th>
                <th>Tipo</th>
                <th>Habilitado</th>
                <th>Guardar</th>
                <th>Eliminar</th>
            </tr>
            </thead>
            <!--<tbody>
            <tr>
                <td><input type="text" class="form-control" id="" value="root"></td>
                <td><input type="password" class="form-control" id="" value="admin"></td>
                <td>deClubMaster</td>
                <td><input type="checkbox" name=""></td>
                <td><button type="button" class="btn btn-primary">Guardar Cambios</button>&nbsp;<button type="button"  data-toggle="tooltip" data-placement="top" title="Eliminar Cuenta" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span></button></td>        
            </tr>
            <tr>
                <td><input type="text" class="form-control" id="" value="root"></td>
                <td><input type="password" class="form-control" id="" value="admin"></td>
                <td>deClubMaster</td>
                <td><input type="checkbox" name=""></td>
                <td><button type="button" class="btn btn-primary">Guardar Cambios</button>&nbsp;<button type="button"  data-toggle="tooltip" data-placement="top" title="Eliminar Cuenta" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span></button></td>    
            </tr>
            </tbody>-->
            </table>
            <?php
            
                    if(empty($_GET['ValidUser']))
                    {
                        // no se puede continuar con la vista de usuarios, es posible que se esté intente accesar sin credenciales
                        echo "  <center><h1> <font color=\"#FDF4E3\"> <font> Lo sentimos no hay resultados. :( </font> </h1> </center>";
                        echo "<script>removeDom();</script>";
                    }
                    else
                    {
                        
                        $response  = NULL;
                        //OjbView sitax: type:value:config   (config) configuración de campo puede ser, algun un color o tamaño para un elemento, etc.          
                        $fields = array("textbox:user_id:none","password:user_password:none","text:user_type:none","checkbox:isvisible:none","button:Guardar Cambios:btn-primary","button:Eliminar Usuario:btn-danger"); 
                        
                        $response = executeHttpRequest("http://localhost/declubmx/executeQuery.php?query=SELECT|user_id,user_password,user_type,CASE|WHEN|CAST%28isVisible|AS|CHAR%29|=|%271%27|THEN|%27checked%27|ELSE|%27|%27|END|AS|isvisible,%27execUpd%28this%29%27|AS|%60Guardar|Cambios%60,%27execDel%28this%29%27|AS|%60Eliminar|Usuario%60|FROM|declub_users;");
                        
                        $response_decoded = json_decode($response,true);
                        //echo count($response_decoded);
                        
                        for($i = 0; $i < count($response_decoded); ++$i) {
                            
                            $DataForResult = NULL;
                            
                            for($j=0;$j<count($fields);$j++)
                            {
                                $ValueFields = NULL;
                                $ValueFields = split(":", $fields[$j]);
                                //echo   "<br>" . $response_decoded[$i][$ValueFields[1]];
                                //                  Tipo de Field      Nombre del Field     Valor de Field from decodedJsonArray     Property        
                                $DataForResult .=  $ValueFields[0].":".$ValueFields[1].":".$response_decoded[$i][$ValueFields[1]].":".$ValueFields[2]."|";
            
                            }
                            //echo "<br>" . $DataForResult;
                            echo "<script>processView('". $DataForResult ."','".$i."');</script>";
                             
                        }
                        
                    }
                   
                function executeHttpRequest($URL) {
                    
                    $curl = curl_init();
                    // Set some options - we are passing in a useragent too here
                    curl_setopt_array($curl, array(
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_URL => $URL,
                        CURLOPT_USERAGENT => 'deClubmx HttpRequest'
                    ));
                    // Send the request & save response to $resp
                    $resp = curl_exec($curl);
                    // Close request to clear up some resources
                    curl_close($curl);
                    return $resp;

                }
            ?>      
    </div>
</div>
<script type="text/javascript">

    
    /*$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
    }); */
</script>
</body>
</html>