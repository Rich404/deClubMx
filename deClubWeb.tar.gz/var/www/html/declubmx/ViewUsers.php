<!DOCTYPE html>
<html lang="es">  
<head>  
    <meta charset="UTF-8">
    <title> Administración - DeClubMx </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet">
    <style>
        .table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
          background-color: #AFAFAF;
        }
    </style> 
</head>  
<body style="background-color:#24384C;">  
<br>
<div class="container" >
        <div class="well">
            <h2>Control de Usuarios</h2>
            <label class="col-sm-1" for="txtTag"> Usuario: </label>
            <div class="col-sm-2 pull-left">
                <input class="form-control" id="txtTag" type="text"> 
            </div>
            <div class="pull-left">
                   <button  onclick="" type="button" class="btn btn-primary"> Añadir Nuevo Usuario </button> 
            </div>
            <table class="table table-hover">
            <thead>
            <tr>
                <th>ID Usuario</th>
                <th>Nombre</th>
                <th>Password</th>
                <th>Tipo</th>
                <th>Habilitado</th>
                <th>Acción</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>1</td>
                <td><input type="text" class="form-control" id="" value="root"></td>
                <td><input type="text" class="form-control" id="" value="admin"></td>
                <td>deClubMaster</td>
                <td><input type="checkbox" name=""></td>
                <td><button type="button" class="btn btn-primary">Guardar Cambios</button>&nbsp;<button type="button"  data-toggle="tooltip" data-placement="top" title="Eliminar Cuenta" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span></button></td>        
            </tr>
            <tr>
            <td>2</td>
                <td><input type="text" class="form-control" id="" value="root"></td>
                <td><input type="text" class="form-control" id="" value="admin"></td>
                <td>deClubMaster</td>
                <td><input type="checkbox" name=""></td>
                <td><button type="button" class="btn btn-primary">Guardar Cambios</button>&nbsp;<button type="button"  data-toggle="tooltip" data-placement="top" title="Eliminar Cuenta" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span></button></td>    
            </tr>
            </tbody>
            </table>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
    });
</script>
</body>
</html>