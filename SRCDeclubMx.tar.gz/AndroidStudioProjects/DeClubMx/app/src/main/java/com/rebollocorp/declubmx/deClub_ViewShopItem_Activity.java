package com.rebollocorp.declubmx;

import android.Manifest;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Parcelable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ExecutionException;

public class deClub_ViewShopItem_Activity extends AppCompatActivity {

    String LOG_TAG = " deClub_LOG : ";
    //private static String msIp = "10.0.0.9";
    public String msIp ;

    Bitmap moBitmapImage = null;
    String msShopData = null;
    ArrayList<JsonData> moaResultJsonShop;
    String msShopOpinionsData = null;
    String msQualitification = null;



    @Override
    protected void onCreate(final Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.xml_declub_viewshopitem_activity);

        msIp = readFileConfig();
        final boolean lbResultCanSave = verifyActivityReloadState(savedInstanceState);
        String loDataId = getIntent().getExtras().getString("DATA_ID");
        msShopData = getJsonResponse(msShopData, "SELECT|id_shop,shop_name,shop_text,shop_latitude,shop_longitude,shop_url_image,shop_qualitification,shop_phone,shop_email,shop_webaddress,shop_address|FROM|declub_shops|WHERE|id_shop|=|'" + loDataId + "'", lbResultCanSave, savedInstanceState, "SHOP_DATA");
        moaResultJsonShop = getJsonArray(msShopData, new String[]{"id_shop", "shop_name", "shop_text", "shop_latitude", "shop_longitude", "shop_url_image", "shop_qualitification", "shop_phone", "shop_email", "shop_webaddress", "shop_address"});

        ImageView loImageShop = (ImageView) findViewById(R.id.imageViewShop);
        moBitmapImage = getBitmapForImage(lbResultCanSave, savedInstanceState, new String[]{moaResultJsonShop.get(0).msFieldbyRow[5]});
        LoadImageWithBitMap loLoadImage = new LoadImageWithBitMap(loImageShop);
        loLoadImage.execute(moBitmapImage);

        TextView loTxtTitle = (TextView) findViewById(R.id.txtTitulo);
        loTxtTitle.setText(moaResultJsonShop.get(0).msFieldbyRow[1]);

        TextView lotxtAddress = (TextView) findViewById(R.id.txtAddress);
        lotxtAddress.setText(moaResultJsonShop.get(0).msFieldbyRow[10]);

        TextView lotxtText = (TextView) findViewById(R.id.txtText);
        lotxtText.setText(moaResultJsonShop.get(0).msFieldbyRow[2]);


        TextView lotxtPhone = (TextView) findViewById(R.id.txtPhone);
        lotxtPhone.setText(moaResultJsonShop.get(0).msFieldbyRow[7]);

        ImageButton loBtnCall = (ImageButton) findViewById(R.id.imageBtnCall);
        loBtnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+moaResultJsonShop.get(0).msFieldbyRow[7]));
                startActivity(intent);
            }
        });

        ImageButton loBtnRoute = (ImageButton) findViewById(R.id.imageBtnRoute);
        loBtnRoute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri gmmIntentUri = Uri.parse("google.navigation:q="+ moaResultJsonShop.get(0).msFieldbyRow[3] +","+moaResultJsonShop.get(0).msFieldbyRow[4]);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        TextView lotxtMail  = (TextView) findViewById(R.id.txtMail);
        lotxtMail.setText(moaResultJsonShop.get(0).msFieldbyRow[8]);

        TextView lotxtWeb  = (TextView) findViewById(R.id.txtWeb);
        lotxtWeb.setText(moaResultJsonShop.get(0).msFieldbyRow[9]);

        RatingBar loRatingStars =  (RatingBar)  findViewById(R.id.ratingBar);
        loRatingStars.setRating(Float.parseFloat(moaResultJsonShop.get(0).msFieldbyRow[6]));

        Button Btnqualify =  (Button) findViewById(R.id.Btnqualify);
        Btnqualify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Dialog dialog = new Dialog(deClub_ViewShopItem_Activity.this);
                dialog.setContentView(R.layout.dialog_qualify_adapter);
                dialog.setTitle("Califica");
                final RatingBar rtbService = (RatingBar) dialog.findViewById(R.id.ratingBarService);
                final RatingBar rtbQuality = (RatingBar) dialog.findViewById(R.id.ratingBarQuality);
                final RatingBar rtbPrice = (RatingBar) dialog.findViewById(R.id.ratingBarPrice);
                final EditText txtmessage = (EditText) dialog.findViewById(R.id.editTextMessage);
                final EditText txtUser = (EditText) dialog.findViewById(R.id.editTextUser);
                Button BtnAcept =  (Button) dialog.findViewById(R.id.BtnAceptqualify);
                BtnAcept.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        /*Log.d(LOG_TAG,String.valueOf(rtbService.getRating()) +String.valueOf(rtbQuality.getRating())+String.valueOf(rtbPrice.getRating())+txtmessage.getText()+txtUser.getText());
                        dialog.dismiss(); */
                        if (!txtmessage.getText().toString().equals("") && !txtUser.getText().toString().equals(""))
                        {

                            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");//dd-MM-yyyy
                            String lsUser = txtUser.getText().toString().replace(" ","\\|");
                            String lsOpinion = txtmessage.getText().toString().replace(" ","\\|");
                            String lsDate =  dateFormat.format(new Date());
                            float lfqualification = (rtbService.getRating() + rtbQuality.getRating() + rtbPrice.getRating()) / 3;
                            Log.d(LOG_TAG,lsDate);
                            String lsResult = ExecuteSqlBatch("INSERT|INTO|declub_shops_opinions|(id_shop,user_name,user_opinion,service,quality,price,final_qualification,opinion_date)|VALUES|('"+moaResultJsonShop.get(0).msFieldbyRow[0]+"','"+lsUser+"','"+ lsOpinion +"',"+String.valueOf(rtbService.getRating())+","+String.valueOf(rtbQuality.getRating())+","+String.valueOf(rtbPrice.getRating())+","+ String.valueOf(lfqualification)+",'"+lsDate+"');");
                            Log.d(LOG_TAG,lsResult);
                            if(lsResult == null || lsResult.contains("2") == true){showToast("Ha ocurrido un error al guardar información.");}else{showToast("Se ha guardado tu opinión.");}
                            dialog.dismiss();
                        }
                        else
                        {
                            showToast("Por favor complete su información.");
                        }


                    }
                });
                dialog.show();

            }
        });

        ImageButton loBtnOpinions = (ImageButton) findViewById(R.id.imageBtnOpinions);
        loBtnOpinions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(deClub_ViewShopItem_Activity.this);
                dialog.setContentView(R.layout.dialog_view_for_opinions_adapter);
                ListView loListOpinions =  (ListView) dialog.findViewById(R.id.lisViewOpinions);
                msShopOpinionsData = getJsonResponse(msShopOpinionsData,"SELECT|id_shop,user_name,user_opinion,final_qualification,opinion_date|FROM|declub_shops_opinions|WHERE|id_shop|=|'"+ moaResultJsonShop.get(0).msFieldbyRow[0]  +"'",lbResultCanSave,savedInstanceState,"SHOP_OPINIONS_DATA");
                ArrayList<JsonData> loJsonData = getJsonArray(msShopOpinionsData,new String[]{"id_shop","user_name","user_opinion","final_qualification","opinion_date"});
                ListViewAdapterOpinions loadapter = new ListViewAdapterOpinions(deClub_ViewShopItem_Activity.this,getStringArrayFromArrayList(loJsonData,1),getStringArrayFromArrayList(loJsonData,2),getStringArrayFromArrayList(loJsonData,3),getStringArrayFromArrayList(loJsonData,4));
                loListOpinions.setAdapter(loadapter);
                dialog.setTitle("Califica");
                dialog.show();
            }
        });

        msQualitification = getJsonResponse(msQualitification,"SELECT|avg(final_qualification)|as|average_qualification|FROM|declub_shops_opinions|WHERE|id_shop|=|'"+moaResultJsonShop.get(0).msFieldbyRow[0]+"'",lbResultCanSave,savedInstanceState,"SHOP_QUALITIFICATION_DATA");
        ArrayList<JsonData> loJsonDataQualitification = getJsonArray(msQualitification,new String[]{"average_qualification"});
        RatingBar loRatingQualitification  = (RatingBar) findViewById(R.id.ratingBar);
        Log.d(LOG_TAG,msQualitification);
        if(!loJsonDataQualitification.get(0).msFieldbyRow[0].equals("null"))
        {
            loRatingQualitification.setRating(Float.parseFloat(loJsonDataQualitification.get(0).msFieldbyRow[0]));
        }
        else
        {
            loRatingQualitification.setRating(1);
        }

        final ImageButton loImgBtnShare = (ImageButton) findViewById(R.id.imageBtnShare);
        loImgBtnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Intent shareIntent = new Intent();
                shareIntent.setAction(Intent.ACTION_SEND);
                shareIntent.putExtra(Intent.EXTRA_STREAM,(Parcelable) moBitmapImage );
                shareIntent.setType("image/jpeg");
                startActivity(Intent.createChooser(shareIntent, "dsfdsf")); */

                //TEXTO
                Intent share = new Intent(android.content.Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "http://beta.directorioempresarial.club/");
                startActivity(Intent.createChooser(share,"Compartir"));
                showToast("Ahora sólo pega nuestro hashtag en tu publicación .");
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("deClub","#DeClubApp");
                clipboard.setPrimaryClip(clip);
                /*showToast(Environment.getExternalStorageDirectory() + File.separator + "jm.jpg");
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("image/*");
                String imagePath = Environment.getExternalStorageDirectory() + File.separator + "jm.jpg";
                File imageFileToShare = new File(imagePath);
                Uri uri = Uri.fromFile(imageFileToShare);
                share.putExtra(Intent.EXTRA_SUBJECT,"OK");
                share.putExtra(Intent.EXTRA_STREAM, uri);
                share.putExtra(Intent.EXTRA_TEXT, "http://www.codeofaninja.com");
                startActivity(Intent.createChooser(share, "Share Image!")); */




            }
        });
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("SHOP_DATA",msShopData);
        outState.putString("SHOP_OPINIONS_DATA",msShopOpinionsData);
        outState.putString("SHOP_QUALITIFICATION_DATA",msQualitification);
        outState.putParcelable("BITMAP_IMAGE",moBitmapImage);
    }
    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if(Build.VERSION.SDK_INT > 23){moBitmapImage = null;}
    }
    public Bitmap getBitmapForImage(boolean lbActivityReloadState,Bundle saveoutState,String [] lsURLsImages)
    {
        Bitmap loBitmapImage = null;
        if(lbActivityReloadState == false || saveoutState.getParcelable("BITMAP_IMAGE") == null)
        {
            GetImageBitmap tg = new GetImageBitmap(this,lsURLsImages);
            try
            {
                loBitmapImage = tg.execute().get()[0];

            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
        else
        {
            loBitmapImage =  (Bitmap) saveoutState.getParcelable("BITMAP_IMAGE");

        }
        return  loBitmapImage;
    }

    public String getJsonResponse(String lsStringJson,String lsQuery,boolean lbResultCanSave,Bundle saveoutState,String lsKey)
    {
        if(lbResultCanSave == false )
        {
            ExecuteHttpRequest loJsonMainData = new ExecuteHttpRequest();
            try {
                lsStringJson = loJsonMainData.execute("http://" + msIp + "/declubmx/executeQuery.php?query=" + lsQuery).get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            return  lsStringJson;
        }
        else
        {
            lsStringJson =  saveoutState.getString(lsKey);
            return lsStringJson;
        }

    }


    public ArrayList<JsonData> getJsonArray(String lsJsonString,String [] lsFields)
    {
        ArrayList<JsonData> loaResultJson  = new ArrayList<JsonData>();
        JsonParser loParser = new JsonParser(lsFields,lsJsonString);
        loaResultJson = loParser.parse();
        return  loaResultJson;
    }

    private boolean verifyActivityReloadState(Bundle losavedInstanceState) {
        if (losavedInstanceState == null) {
            Log.d(LOG_TAG, " No hay Actividad a Restaurar");
            return false;
        } else {
            Log.d(LOG_TAG, " Se puede restaurar actividad ");
            return true;
        }
    }

    public void showToast(String lsString)
    {
        Toast.makeText(getApplicationContext(),lsString,Toast.LENGTH_SHORT).show();
    }
    public String ExecuteSqlBatch(String lsQuery)
    {
        ExecuteHttpRequest loRequest = new ExecuteHttpRequest();
        String lsResult = null;
        try {
            lsResult = loRequest.execute("http://" + msIp + "/declubmx/executeCommand.php?query=" + lsQuery).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return lsResult;
    }
    public String [] getStringArrayFromArrayList(ArrayList<JsonData> loa,int lsField)
    {
        String [] lsArray = new String[loa.size()];

        for(int lii = 0;lii < loa.size();lii++)
        {
            lsArray [lii] = loa.get(lii).msFieldbyRow[lsField];
        }

        return  lsArray;
    }

    public String  readFileConfig()
    {
        ExecuteHttpRequest loRequest = new ExecuteHttpRequest();
        String lsResult = null;
        try {
            lsResult = loRequest.execute("https://raw.githubusercontent.com/Rich404/deClubMx/master/host").get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        //Log.d(LOG_TAG,lsResult);
        return lsResult;

    }
}
