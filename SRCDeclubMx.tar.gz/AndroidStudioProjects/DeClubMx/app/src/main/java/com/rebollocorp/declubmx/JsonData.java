package com.rebollocorp.declubmx;

import android.util.Log;

/**
 * Created by hpadmin on 11/08/17.
 */

public class  JsonData
{
    String lsRow;
    String[] msFieldbyRow;
    String LOG_TAG = " deClub_LOG : ";

    public void setLsRow(String lsRow) {
        this.lsRow = lsRow;
    }

    public void setMsFieldbyRow(String[] msFieldbyRow) {
        this.msFieldbyRow = msFieldbyRow;
    }

    public  void ViewData(){
        int i=0;
        Log.d(LOG_TAG,lsRow);
        while(i < msFieldbyRow.length)
        {
            Log.d(LOG_TAG,msFieldbyRow[i]);
            i++;
        }
    }
}