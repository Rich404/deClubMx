package com.rebollocorp.declubmx;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by hpadmin on 22/07/17. Esta Clase no Renderiza bien  los views
 */

public class ListViewAdapter extends BaseAdapter {

    Context mContext;
    String[] msBrandName,msAdress,Km;
    Bitmap[] moBitmap;

    public ListViewAdapter(Context context, String[] lsBrandName,String[] lsAdress,Bitmap[] moBitmap,String [] Km) {
        this.mContext = context;
        this.msBrandName = lsBrandName;
        this.moBitmap = moBitmap;
        this.msAdress = lsAdress;
        this.Km = Km;
    }

    @Override
    public int getCount() {
        return moBitmap.length;
    }


    @Override
    public Object getItem(int i) {
        return msBrandName[i];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        View v = convertView;

        if (convertView == null) {
            LayoutInflater inf = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inf.inflate(R.layout.list_view_adapter, null);
        }

        TextView title = (TextView) v.findViewById(R.id.lbltitle);
        title.setText(msBrandName[i]);

        TextView description = (TextView) v.findViewById(R.id.lblDescription);
        description.setText(msAdress[i]);

        TextView distance   =  (TextView) v.findViewById(R.id.lblDescription);
        distance.setText(Km[i]);
        ImageView imagen = (ImageView) v.findViewById(R.id.imageViewBrand);
        //imagen.setImageDrawable(dir.getImage());
        LoadImageWithBitMap loLoadImageBitmap =  new LoadImageWithBitMap(imagen);
        loLoadImageBitmap.execute(moBitmap[i]);
        return v;
    }
    /*@Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        View v = convertView;

        if (convertView == null) {
            LayoutInflater inf = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inf.inflate(R.layout.list_view_adapter, null);
            TextView title = (TextView) v.findViewById(R.id.lbltitle);
            title.setText(msBrandName[i]);

            TextView description = (TextView) v.findViewById(R.id.lblDescription);
            description.setText(msAdress[i]);

            TextView distance   =  (TextView) v.findViewById(R.id.lblDescription);
            distance.setText(Km[i]);
            ImageView imagen = (ImageView) v.findViewById(R.id.imageViewBrand);
            //imagen.setImageDrawable(dir.getImage());
            LoadImageWithBitMap loLoadImageBitmap =  new LoadImageWithBitMap(imagen);
            loLoadImageBitmap.execute(moBitmap[i]);

        }
        else{
            v = (View) convertView;
        }

        return v;
    }*/
   /* @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View ViewAndroid = new View(mContext);
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (view == null)
        {
            ViewAndroid = inflater.inflate(R.layout.list_view_adapter, null);
            ImageView imageViewAndroid = (ImageView) ViewAndroid.findViewById(R.id.imageViewBrand);
            TextView textViewAndroid = (TextView) ViewAndroid.findViewById(R.id.lbltitle);
            TextView textViewAndroidDesc = (TextView) ViewAndroid.findViewById(R.id.lblDescription);
            TextView textViewAndroidKM = (TextView) ViewAndroid.findViewById(R.id.lblDistanceKM);
            textViewAndroid.setText(msBrandName[i]);
            textViewAndroidDesc.setText(msAdress[i]);
            textViewAndroidKM.setText(Km[i]);
            LoadImageWithBitMap loLoadImageBitmap =  new LoadImageWithBitMap(imageViewAndroid);
            loLoadImageBitmap.execute(moBitmap[i]);
        } else {
            ViewAndroid = (View) view;
        }

        return ViewAndroid;
    } */


}
