package com.rebollocorp.declubmx;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * Created by hpadmin on 20/08/17.
 */

public class GetImageBitmap extends AsyncTask<String, Void, Bitmap[]>{
    Context goContext;
    String [] goUrlStringArray  ;
    String LOG_TAG = " deClub_LOG : ";


    public GetImageBitmap(Context goContext, String[] goUrlStringArray) {
        this.goContext = goContext;
        this.goUrlStringArray = goUrlStringArray;

    }

    @Override
    protected Bitmap[] doInBackground(String... loUrlStringArray) {
        loUrlStringArray = this.goUrlStringArray;
        Bitmap[] laoBitmap = new Bitmap[goUrlStringArray.length];
        for (int lii = 0 ;  lii < laoBitmap.length; lii++)
        {
            //laoBitmap [lii] = downloadImage(loUrlStringArray[lii]);
            try {
                laoBitmap[lii] = BitmapFactory.decodeStream((InputStream)new URL(loUrlStringArray[lii]).getContent());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return  laoBitmap;
    }

    @Override
    protected void onPostExecute(Bitmap[] bitmaps) {
        Log.d(LOG_TAG, " Finalizo Peticion HTTP para BITMAP");
    }

    /*private Bitmap downloadImage(String url)
    {
        Bitmap bitmap = null;
        InputStream stream = null;
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inSampleSize = 1;
        try
        {
            stream = getHttpConnection(url);
            bitmap = BitmapFactory.decodeStream(stream, null, bmOptions);
            stream.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return bitmap;
    }
    private InputStream getHttpConnection(String urlString) throws IOException {
        InputStream stream = null;
        URL url = new URL(urlString);
        URLConnection connection = url.openConnection();
        try {
            HttpURLConnection httpConnection = (HttpURLConnection) connection;
            httpConnection.setRequestMethod("GET");
            httpConnection.connect();
            if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                stream = httpConnection.getInputStream();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return stream;
    }*/
}
