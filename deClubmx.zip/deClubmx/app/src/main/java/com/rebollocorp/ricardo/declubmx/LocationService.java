package com.rebollocorp.ricardo.declubmx;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.Gravity;
import android.widget.Toast;

import static android.location.LocationManager.*;

/**
 * Created by hpadmin on 14/07/17.
 */

public class LocationService implements LocationListener  {

    Context moContext;
    Location moLocation;
    boolean moHardwareLocationStatus = true;

    public Context getMoContext() {
        return moContext;
    }

    public void setMoContext(Context moContext) {
        this.moContext = moContext;
    }

    public boolean isMoHardwareLocationStatus() {
        return moHardwareLocationStatus;
    }

    public void setMoHardwareLocationStatus(boolean moHardwareLocationStatus) {
        this.moHardwareLocationStatus = moHardwareLocationStatus;
    }

    public Location getMoLocation() {
        return moLocation;
    }

    public void setMoLocation(Location moLocation) {
        this.moLocation = moLocation;
    }

    public LocationService(Context moContext) {
        this.moContext = moContext;
    }

    @Override
    public void onLocationChanged(Location location) {
        Toast.makeText(moContext,"* Se ha Actializado *",Toast.LENGTH_SHORT).show();
        setMoLocation(location);
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {
        Toast.makeText(moContext,"Proveedor " + s +" Status"+String.valueOf(i),Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProviderEnabled(String s) {
        Toast.makeText(moContext,"* Se ha Habilitado",Toast.LENGTH_SHORT).show();
        setMoHardwareLocationStatus(true);

    }

    @Override
    public void onProviderDisabled(String s) {
        Toast.makeText(moContext,"* Se ha Deshabilitado",Toast.LENGTH_SHORT).show();
        setMoHardwareLocationStatus(false);
    }




}
