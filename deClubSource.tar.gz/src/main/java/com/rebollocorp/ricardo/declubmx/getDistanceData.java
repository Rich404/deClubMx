package com.rebollocorp.ricardo.declubmx;

import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by hpadmin on 31/07/17.
 */


public class getDistanceData  extends AsyncTask<String,Void,InputStream>
{

    @Override
    protected InputStream doInBackground(String... strings) {
        InputStream loInputStream = null;
        try {
            loInputStream =  getHttpConnection(strings[0]);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return loInputStream;
    }

    private InputStream getHttpConnection(String urlString) throws IOException
    {
        InputStream stream = null;
        URL url = new URL(urlString);
        URLConnection connection = url.openConnection();
        try
        {
            HttpURLConnection httpConnection = (HttpURLConnection) connection;
            httpConnection.setRequestMethod("GET"); httpConnection.connect();
            if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK)
            {
                stream = httpConnection.getInputStream();

            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return stream;
    }


}