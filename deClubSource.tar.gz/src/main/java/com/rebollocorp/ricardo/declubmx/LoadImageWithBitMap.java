package com.rebollocorp.ricardo.declubmx;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

/**
 * Created by hpadmin on 20/07/17.
 */

public class LoadImageWithBitMap extends AsyncTask<Bitmap,Void,Bitmap> {
    ImageView img;
    public LoadImageWithBitMap(ImageView img){
        this.img=img;

    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Bitmap... bitmaps) {
        Bitmap bitmap= bitmaps[0];
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        if(bitmap != null){
            // Se hizo esto para despues , en vez de hacer el request en el hilo, solo asignar el Bitmap en el ViewPager
            img.setImageBitmap(bitmap);
            Log.d(" OUTPUT :: ","Se Asigno BITMAP");
        }
    }

}
