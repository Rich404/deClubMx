package com.rebollocorp.ricardo.declubmx;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.ExecutionException;

public class deClub_ShopsList_Activity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xml_declub_shopslist_activity);

        String [] lsLocation =  getIntent().getExtras().getStringArray("Location");
        Toast.makeText(getApplicationContext(), "Ultima Ubicación" + lsLocation[0]+","+lsLocation[1], Toast.LENGTH_SHORT).show();

        String [] loLocations = new String[]{"19.557431+-99.246572","19.530875+-99.224759","19.557431+-99.246572","19.530875+-99.224759","19.557431+-99.246572"};
        String [] lsKmResult =  new String[loLocations.length];
        for(int i = 0; i <loLocations.length;i++)
        {
            String [] lastmp = loLocations[i].split("\\+");
            getDistanceData getData = new getDistanceData();
            try
            {
                InputStream loInputStream = getData.execute("http://maps.googleapis.com/maps/api/distancematrix/json?origins="+lsLocation[0]+","+lsLocation[1]+"&destinations="+lastmp[0]+","+lastmp[1]+"&mode=walking&language=en&sensor=false%27").get();
                parseJsonDistanceData loData =  new parseJsonDistanceData(loInputStream);
                loData.parse();
                lsKmResult [i] = loData.getLsKM();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }

        setListViewValues(lsKmResult);

    }

    public void setListViewValues(String []lsKmResultForTxt)
    {
        ListView loListViewShops = (ListView) findViewById(R.id.layoutListShops);
        GetImageBitmap tg = new GetImageBitmap(this,new String[]{"http://www.mundoflaneur.com/wp-content/uploads/2014/02/Directo-campo-ILOVEFOOD.jpg","http://pizzeriadoboludo.com/img/pizzas2.jpg","https://static.websguru.com.ar/var/m_2/21/217/78929/1160339-icono-1.png","https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/01_Tacos_al_Pastor.jpg/240px-01_Tacos_al_Pastor.jpg","https://s-media-cache-ak0.pinimg.com/originals/b4/76/e4/b476e463e5b5cebebfb3f0d4175544cd.jpg"});
        try
        {
            Bitmap[] goBitMapArray = tg.execute().get();
            Log.d(" OUTPUT :: ",String.valueOf(goBitMapArray.length));
            ListViewAdapter loListViewAdapter =  new ListViewAdapter(deClub_ShopsList_Activity.this,new String[]{"Supermercado","Pizza","Refaccionarias","Safari","Cafeterías"},new String[]{"Local 4, Boulevar Adolfo López Mateos Norte 138, Las Alamedas, 52970 Cd López Mateos, Estado de México","Safari, Avenida Convento de Tepotzotlán, Habitacional Jardines de Santa Monica, Estado de México","Safari, Avenida Convento de Tepotzotlán, Habitacional Jardines de Santa Monica, Estado de México","Safari, Avenida Convento de Tepotzotlán, Habitacional Jardines de Santa Monica, Estado de México","Local 4, Boulevar Adolfo López Mateos Norte 138, Las Alamedas, 52970 Cd López Mateos, Estado de México"},goBitMapArray,lsKmResultForTxt);
            loListViewShops.setAdapter(loListViewAdapter);
            loListViewShops.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    Intent IntentViewShop = new Intent(view.getContext(),deClub_ViewShopItem_Activity.class);
                    startActivity(IntentViewShop);
                }
            });

        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }




    private class parseJsonDistanceData {
        InputStream FullJsonStream ;
        String lsKM;

        public String getLsKM() {
            return lsKM;
        }

        public void setLsKM(String lsKM) {
            this.lsKM = lsKM;
        }

        public parseJsonDistanceData(InputStream FullJsonStream) {
            this.FullJsonStream = FullJsonStream;
        }

        public void parse() {
            try
            {
                String lsResult = convertInputStreamToString(FullJsonStream);

                JSONObject loJsonreader = new JSONObject(lsResult.trim());
                String lsDestination =loJsonreader.getString("destination_addresses");
                Log.d(" OUTPUT :: ",lsDestination);
                String lsOrigin =loJsonreader.getString("origin_addresses");
                Log.d(" OUTPUT :: ",lsOrigin);

                JSONArray laoRows = loJsonreader.getJSONArray("rows");// Obtencion de row array
                Log.d(" OUTPUT :: ",laoRows.toString());

                JSONObject lsElemntFromRow = laoRows.getJSONObject(0);//Se Obtiene  la  Pirmera posición , ya que solo hay un elemento
                JSONArray laoElements = lsElemntFromRow.getJSONArray("elements");// Obtencion de elements array
                Log.d(" OUTPUT :: ", laoElements.toString());

                JSONObject loElement = laoElements.getJSONObject(0);//Se Obtiene  la  Pirmera posición , ya que solo hay un elemento
                Log.d(" OUTPUT :: ", loElement.toString());

                JSONObject loDistance = loElement.getJSONObject("distance");
                Log.d(" OUTPUT :: ", loDistance.toString());

                String lsDistance = loDistance.getString("text");
                Log.d(" OUTPUT :: ", lsDistance.toString());
                setLsKM(lsDistance.toString());
                //*** POR AHORA SOLO SE NECESITA EXTRAER LOS KM DE DISTANCIA **//

                String lsStatus =loJsonreader.getString("status");
                Log.d(" OUTPUT :: ",lsStatus);
            }
            catch (JSONException e)
            {
                Log.d(" OUTPUT :: ",e.toString());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        public String convertInputStreamToString(InputStream is) throws IOException, UnsupportedEncodingException {
            InputStreamReader isr = null;
            BufferedReader br = null;
            StringBuilder sb = new StringBuilder();
            String content;
            try
            {
                isr = new InputStreamReader(is);
                br = new BufferedReader(isr);
                while ((content = br.readLine()) != null)
                {
                    sb.append(content);
                }
            } catch (IOException ioe)
            {
                Log.d(" OUTPUT :: ",ioe.toString());
                ioe.printStackTrace();
            }
            finally
            {
                isr.close();
                br.close();
            }

            return sb.toString();
        }

    }


}
