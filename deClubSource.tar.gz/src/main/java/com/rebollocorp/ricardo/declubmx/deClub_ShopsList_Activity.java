package com.rebollocorp.ricardo.declubmx;

import android.graphics.Bitmap;
import android.location.Location;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class deClub_ShopsList_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xml_declub_shopslist_activity);

        String [] lsLocation =  getIntent().getExtras().getStringArray("Location");
        Toast.makeText(getApplicationContext(), "Ultima Ubicación" + lsLocation[0]+","+lsLocation[1], Toast.LENGTH_SHORT).show();

        ListView loListViewShops = (ListView) findViewById(R.id.layoutListShops);
        GetImageBitmap tg = new GetImageBitmap(this,new String[]{"https://previews.123rf.com/images/simmmax/simmmax1509/simmmax150900045/44521020-Supermercado-icono-de-carrito-de-la-compra-Foto-de-archivo.jpg"
                ,"https://upload.wikimedia.org/wikipedia/fr/4/40/Ph2016.png","https://static.websguru.com.ar/var/m_2/21/217/78929/1160339-icono-1.png","https://previews.123rf.com/images/cowpland/cowpland1411/cowpland141100190/33723217-Construcci-n-de-escuelas-icono-plana-moderna-con-larga-sombra-Foto-de-archivo.jpg","https://cdn.pixabay.com/photo/2014/04/03/09/59/cup-309508_960_720.png"});
        try
        {
            Bitmap[] goBitMapArray = tg.execute().get();
            Log.d(" OUTPUT :: ",String.valueOf(goBitMapArray.length));
            ListViewAdapter loListViewAdapter =  new ListViewAdapter(deClub_ShopsList_Activity.this,new String[]{"Supermercado","Pizza","Refaccionarias","Escuelas","Cafeterías"},new String[]{"Local 4, Boulevar Adolfo López Mateos Norte 138, Las Alamedas, 52970 Cd López Mateos, Estado de México","Local 4, Boulevar Adolfo López Mateos Norte 138, Las Alamedas, 52970 Cd López Mateos, Estado de México","Local 4, Boulevar Adolfo López Mateos Norte 138, Las Alamedas, 52970 Cd López Mateos, Estado de México","Local 4, Boulevar Adolfo López Mateos Norte 138, Las Alamedas, 52970 Cd López Mateos, Estado de México","Local 4, Boulevar Adolfo López Mateos Norte 138, Las Alamedas, 52970 Cd López Mateos, Estado de México","Local 4, Boulevar Adolfo López Mateos Norte 138, Las Alamedas, 52970 Cd López Mateos, Estado de México"},goBitMapArray);
            loListViewShops.setAdapter(loListViewAdapter);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        new DownloadTask().execute("http://maps.googleapis.com/maps/api/distancematrix/json?origins=19.543731,-99.250458&destinations=19.558181,-99.246593&mode=driving&language=en&sensor=false%27");


    }

    private class DownloadTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            //do your request in here so that you don't interrupt the UI thread
            try {
                return downloadContent(params[0]);
            } catch (IOException e) {
                return "Unable to retrieve data. URL may be invalid.";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            //Here you are done with the task
            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
        }
    }

    private String downloadContent(String myurl) throws IOException {
        InputStream is = null;
        int length = 500;

        try {
            URL url = new URL(myurl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000 /* milliseconds */);
            conn.setConnectTimeout(15000 /* milliseconds */);
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.connect();
            int response = conn.getResponseCode();
            Log.d(" OUTPUT :: ", "The response is: " + response);
            is = conn.getInputStream();

            // Convert the InputStream into a string
            String contentAsString = convertInputStreamToString(is, length);
            return contentAsString;
        } finally {
            if (is != null) {
                is.close();
            }
        }
    }

    public String convertInputStreamToString(InputStream stream, int length) throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(stream, "UTF-8");
        char[] buffer = new char[length];
        reader.read(buffer);
        return new String(buffer);
    }



}
