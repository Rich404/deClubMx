package com.camacho.ricardo.testlocation;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by hpadmin on 22/07/17.
 */

public class ListViewItem extends BaseAdapter {

    Context mContext;
    String[] msBrandName,msAdress,Km;
    Bitmap[] moBitmap;

    public ListViewItem(Context context, String[] lsBrandName,String[] lsAdress,String [] Km) {
        this.mContext = context;
        this.msBrandName = lsBrandName;
        this.msAdress = lsAdress;
        this.Km = Km;
    }

    @Override
    public int getCount() {
        return moBitmap.length;
    }


    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
         CardView ViewAndroid = new CardView(mContext);
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (view == null)
        {
            ViewAndroid = (CardView) inflater.inflate(R.layout.storeitem, null);
            ImageView imageViewAndroid = (ImageView) ViewAndroid.findViewById(R.id.imgview);
            TextView textViewAndroid = (TextView) ViewAndroid.findViewById(R.id.txt2);
            imageViewAndroid.setImageResource(R.drawable.m3);
            textViewAndroid.setText(msBrandName[i]);
            /* LoadImageWithBitMap loLoadImageBitmap =  new LoadImageWithBitMap(imageViewAndroid);
            loLoadImageBitmap.execute(moBitmap[i]); */
        } else {
            ViewAndroid = (CardView) view;
        }

        return ViewAndroid;
    }
}
