package com.rebollocorp.ricardo.declubmx;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by hpadmin on 8/07/17.
 */

public class GetImageBitmap extends AsyncTask <String, Void, Bitmap[]>{


    Context goContext;
    String [] goUrlStringArray  ;


    public GetImageBitmap(Context goContext, String[] goUrlStringArray) {
        this.goContext = goContext;
        this.goUrlStringArray = goUrlStringArray;

    }

    @Override
    protected Bitmap[] doInBackground(String... loUrlStringArray) {
        loUrlStringArray = this.goUrlStringArray;
        Bitmap[] laoBitmap = new Bitmap[goUrlStringArray.length];
            for (int lii = 0 ;  lii < laoBitmap.length; lii++)
            {
                laoBitmap [lii] = downloadImage(loUrlStringArray[lii]);
            }
        return  laoBitmap;
    }

    @Override
    protected void onPostExecute(Bitmap[] bitmaps) {


            if (bitmaps[0].getByteCount() == 0) {
                Log.d(" OUTPUT :: ", "Esta vacio");
            } else {
                Log.d(" OUTPUT :: ", "BitMap lleno");
            }


    }

    private Bitmap downloadImage(String url)
    {
        Bitmap bitmap = null;
        InputStream stream = null;
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inSampleSize = 1;
        try
        {
            stream = getHttpConnection(url);
            bitmap = BitmapFactory.decodeStream(stream, null, bmOptions);
            stream.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return bitmap;
    }
    private InputStream getHttpConnection(String urlString) throws IOException
    {
        InputStream stream = null;
        URL url = new URL(urlString);
        URLConnection connection = url.openConnection();
        try
        {
            HttpURLConnection httpConnection = (HttpURLConnection) connection;
            httpConnection.setRequestMethod("GET"); httpConnection.connect();
            if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK)
            {
                stream = httpConnection.getInputStream();
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return stream;
    }
}
