package com.rebollocorp.ricardo.declubmx;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by hpadmin on 31/07/17.
 */


public class ExecuteHttpRequest extends AsyncTask<String,Void,String>
{

    @Override
    protected String doInBackground(String... strings) {
        InputStream loInputStream = null;
        String lsResult =null;
        try {
            loInputStream =  getHttpConnection(strings[0]);
            lsResult  = convertInputStreamToString(loInputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lsResult;
    }

    private InputStream getHttpConnection(String urlString) throws IOException
    {
        InputStream stream = null;
        URL url = new URL(urlString);
        URLConnection connection = url.openConnection();
        try
        {
            HttpURLConnection httpConnection = (HttpURLConnection) connection;
            httpConnection.setRequestMethod("GET"); httpConnection.connect();
            if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK)
            {
                stream = httpConnection.getInputStream();

            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return stream;
    }

    public String convertInputStreamToString(InputStream is) throws IOException, UnsupportedEncodingException {
        InputStreamReader isr = null;
        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();
        String content;
        try
        {
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);
            while ((content = br.readLine()) != null)
            {
                sb.append(content);
            }
        } catch (IOException ioe)
        {
            Log.d(" OUTPUT :: ",ioe.toString());
            ioe.printStackTrace();
        }
        finally
        {
            isr.close();
            br.close();
        }

        return sb.toString();
    }


}