package com.rebollocorp.ricardo.declubmx;

import android.util.Log;

/**
 * Created by hpadmin on 11/08/17.
 */

public class  JsonData
{
    String lsRow;
    String[] msFieldbyRow;

    public String getLsRow() {
        return lsRow;
    }

    public void setLsRow(String lsRow) {
        this.lsRow = lsRow;
    }

    public String[] getMsFieldbyRow() {
        return msFieldbyRow;
    }

    public void setMsFieldbyRow(String[] msFieldbyRow) {
        this.msFieldbyRow = msFieldbyRow;
    }

    public  void ViewData(){
        int i=0;
        Log.d(" OUTPUT :: ",lsRow);
        while(i < msFieldbyRow.length)
        {
            Log.d(" OUTPUT :: ",msFieldbyRow[i]);
            i++;
        }
    }
}