package com.rebollocorp.ricardo.declubmx;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;

public class deClub_Main_Activity extends AppCompatActivity {

    LocationService mocationService ;
    LocationManager mocationManager;
    Location moLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xml_declub_main_activity);
        EditText  TxtTag = (EditText) findViewById(R.id.TxtSearch);
        TxtTag.setFocusable(false);
        boolean loPermission = getLocationPermission();

        if(loPermission == false)
        {
            buildAlertMessageNoGps();
        }
        else
        {
            callLocationService();
            setSpinnerValues();
            setViewPagerValues();
            setGridCategoriesValues();
            setImageButtonValues();
            setSearchButtonValues();
        }



    }

    public void setSpinnerValues()
    {
        // ---- Codigo de Spinner
        final Spinner Obspinner = (Spinner) findViewById(R.id.SpinnerCategory);
        String [] SpinnerCategoryValues = {"Todo","Cafeterías","Escuelas","Refaccionarias"};
        Obspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        ArrayAdapter<String> SpinnerdataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, SpinnerCategoryValues);
        SpinnerdataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Obspinner.setAdapter(SpinnerdataAdapter);
    }

    public void setViewPagerValues()
    {
        ViewPager ViewPagerURL = (ViewPager) findViewById(R.id.ViewPagerSliderURL);
        GetImageBitmap tg = new GetImageBitmap(this,new String[]
                {"http://eltriangulo.mx/multimedia/imagenes/directorio/4176aaf0c81caf62375caa44aabba6533310066b.jpg",
                        "http://i.anunciosya.com.mx/i-a/Rdwo-1.jpeg",
                        "http://4.bp.blogspot.com/-Uc3f6-glrEs/T8_YO4SlfLI/AAAAAAAAABY/Zb7mnHxS0Ho/s1600/Escuela.jpg",
                        "http://www.vanguardia.com.mx/sites/default/files/pizza-pepperoni-w857h456_0.jpg"});
        try
        {
            Bitmap [] goBitMapArray = tg.execute().get();
            Log.d(" OUTPUT :: ",String.valueOf(goBitMapArray.length));
            PageViewAdapter adap =  new PageViewAdapter(this,goBitMapArray);
            ViewPagerURL.setAdapter(adap);

        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    public void setImageButtonValues ()
    {
        final ImageButton  loImageButtonLocation = (ImageButton) findViewById(R.id.ImgBtnLocation);
        loImageButtonLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loImageButtonLocation.setImageResource(R.drawable.location_image_icon_pressed);
                if(mocationService.isMoHardwareLocationStatus() == true)
                {
                    Log.d(" OUT :: "," Ubicacion Encendida");
                    showProgressDialog();
                }
                else if(mocationService.isMoHardwareLocationStatus() == false)
                {
                    Log.d(" OUT :: "," Ubicacion apagada");
                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    showProgressDialog();
                }
                else
                {
                    Log.d(" OUT :: ","  Otro Evento de Ubicacion");
                }
                //showLocationSettings();
                //callLocationService();

                //mocationManager.removeUpdates(mocationService);
                //mocationManager = null;
            }
        });
    }

    public void setSearchButtonValues()
    {
        final Button loBtnSearch = (Button) findViewById(R.id.BtnSearch);
        loBtnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               if(moLocation != null)//Comantado solo para puevas de ShopList Activity
                {
                    //Toast.makeText(getApplicationContext(), "Ultima Ubicación" + moLocation.getLatitude() +","+moLocation.getLongitude(), Toast.LENGTH_SHORT).show();
                    Intent IntentShopsList = new Intent(view.getContext(),deClub_ShopsList_Activity.class);
                    IntentShopsList.putExtra("Location",new String[]{String.valueOf(moLocation.getLatitude()),String.valueOf(moLocation.getLongitude())});
                    startActivity(IntentShopsList);
                    //startActivityForResult(IntentShopsList, 0);
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Porfavor pulse el boton de ubicacion", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void callLocationService()
    {

            mocationService =  new LocationService(deClub_Main_Activity.this);
            mocationManager = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
            List<String> loProviders = mocationManager.getAllProviders();
            if(loProviders.contains("network")  == true)
            {
                int permissionCheck = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
                int permissionCheck2 = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION);
                mocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1000,0, mocationService);

            }
            else
            {
                int permissionCheck = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
                int permissionCheck2 = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION);
                mocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0, mocationService);

            }


   }
    public  void showProgressDialog()
    {
        final ProgressDialog loProgress = new ProgressDialog(deClub_Main_Activity.this);
        loProgress.setMessage("Encontrando su ubicacion");
        loProgress.setCancelable(false);
        loProgress.show();

        final Timer loTimerLocation = new Timer();
        TimerTask loTaskTimerLocation = new TimerTask() {

            @Override
            public void run()
            {

                if(mocationService.getMoLocation() == null )
                {
                    Log.d(" OUT :: ","Es null ");

                }
                else
                {

                    Log.d(" OUT :: ","NO ES null ");
                    loProgress.dismiss();
                    loTimerLocation.cancel();
                    moLocation = mocationService.getMoLocation();
                    Log.d(" OUT :: ",String.valueOf(mocationService.getMoLocation().getLatitude() +","+mocationService.getMoLocation().getLongitude()));
                    mocationService.setMoLocation(null);

                }
            }
        };
        loTimerLocation.schedule(loTaskTimerLocation,0,1000);

    }

    public  void setGridCategoriesValues()
    {
        GridView loGridCategories = (GridView) findViewById(R.id.GridCategoryItems);
        GetImageBitmap tg = new GetImageBitmap(this,new String[]{"https://previews.123rf.com/images/simmmax/simmmax1509/simmmax150900045/44521020-Supermercado-icono-de-carrito-de-la-compra-Foto-de-archivo.jpg"
                ,"https://upload.wikimedia.org/wikipedia/fr/4/40/Ph2016.png","https://static.websguru.com.ar/var/m_2/21/217/78929/1160339-icono-1.png","https://previews.123rf.com/images/cowpland/cowpland1411/cowpland141100190/33723217-Construcci-n-de-escuelas-icono-plana-moderna-con-larga-sombra-Foto-de-archivo.jpg","https://cdn.pixabay.com/photo/2014/04/03/09/59/cup-309508_960_720.png"});
        try
        {
            Bitmap[] goBitMapArray = tg.execute().get();
            Log.d(" OUTPUT :: ",String.valueOf(goBitMapArray.length));
            GridViewAdapter loGridAdapter =  new GridViewAdapter(deClub_Main_Activity.this,new String[]{"Supermercado","Pizza","Refaccionarias","Escuelas","Cafeterías"},goBitMapArray);
            loGridCategories.setAdapter(loGridAdapter);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

    }

    public boolean getLocationPermission()
    {
        if( ActivityCompat.checkSelfPermission(deClub_Main_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED  || ActivityCompat.checkSelfPermission(deClub_Main_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED )
        {
            Log.d(" OUT :: ","Si Tiene Permisos");
            return true;
        }
        else
        {

            Log.d(" OUT :: ","NO Tiene Permisos");
            return false;
        }
    }
    protected void buildAlertMessageNoGps() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Porfavor de permisos para la ubicacion ,esto solo se pedira una vez . Depsues abra de nuevo la aplicacion para que se ven reflejados los cambios")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        new Thread(new Runnable() {
                            public void run() {
                                ActivityCompat.requestPermissions(deClub_Main_Activity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                                SystemClock.sleep(4000);
                                finish();
                            }
                        }).start();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        finish();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    /*public void GetLocation(Location loLocation)
    {
        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());

        try {
            addresses = geocoder.getFromLocation( loLocation.getLatitude(),  loLocation.getLongitude(), 1);
            String address = addresses.get(0).getAddressLine(0);
            Toast.makeText(getApplicationContext(), "Nueva ubicacion" + loLocation.getLatitude() +","+loLocation.getLongitude() +" "+address, Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    } */

}
