package com.rebollocorp.declubmx;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class deClub_ShopsList_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xml_declub_shopslist_activity);
    }
}
