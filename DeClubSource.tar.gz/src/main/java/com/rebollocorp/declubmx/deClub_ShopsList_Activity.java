package com.rebollocorp.declubmx;

import android.graphics.Bitmap;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class deClub_ShopsList_Activity extends AppCompatActivity {
    String LOG_TAG = " deClub_LOG : ";
    private static String msIp = "10.0.0.9";
    String[] msLocation;
    String msJsonString;


    /* ListView  */
    ListView moListViewShops;
    ArrayList<JsonData> moaResultJsonListView;
    String [] msKmResult = null;
    Bitmap [] moBitMapArrayShops =  null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xml_declub_shopslist_activity);

        boolean lbResultCanSave = verifyActivityReloadState(savedInstanceState);

        if (lbResultCanSave == false) {
            msLocation = getIntent().getExtras().getStringArray("LOCATION");
            msJsonString = getIntent().getExtras().getString("JSON_RESULT");
        } else {
            msLocation = savedInstanceState.getStringArray("LOCATION");
            msJsonString = savedInstanceState.getString("JSON_RESULT_KEY");
        }

        moListViewShops = (ListView) findViewById(R.id.layoutListShops);
        moaResultJsonListView = getJsonArray(msJsonString, new String[]{"id_shop", "shop_name", "shop_text", "shop_latitude", "shop_longitude", "shop_url_image", "shop_qualitification"});
        String[] lsArray = getStringArrayFromArrayList(moaResultJsonListView, 3, 4);
        msKmResult = getKmForShops(lbResultCanSave,savedInstanceState,lsArray);
        fillListViewData(lbResultCanSave,savedInstanceState,getStringArrayFromArrayListSingleColumn(moaResultJsonListView,5),getStringArrayFromArrayListSingleColumn(moaResultJsonListView,1),getStringArrayFromArrayListSingleColumn(moaResultJsonListView,2),msKmResult,getIntArrayFromArrayListSingleColumn(moaResultJsonListView,6));


        /* SI FUNCIONA
        GetImageBitmap tg = new GetImageBitmap(this,new String[]{"http://www.mundoflaneur.com/wp-content/uploads/2014/02/Directo-campo-ILOVEFOOD.jpg","http://pizzeriadoboludo.com/img/pizzas2.jpg","https://static.websguru.com.ar/var/m_2/21/217/78929/1160339-icono-1.png","https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/01_Tacos_al_Pastor.jpg/240px-01_Tacos_al_Pastor.jpg","https://s-media-cache-ak0.pinimg.com/originals/b4/76/e4/b476e463e5b5cebebfb3f0d4175544cd.jpg"});
        try
        {
            Bitmap[] goBitMapArray = tg.execute().get();
            ListAdapter loListViewAdapter =  new ListAdapter(this,new String[]{"Supermercado","Pizza","Refaccionarias","Safari","Cafeterías"},goBitMapArray);
            loListViewShops.setAdapter(loListViewAdapter);

        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        */


    }
    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if(Build.VERSION.SDK_INT > 23){moBitMapArrayShops=null;}
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("JSON_RESULT_KEY", msJsonString);
        outState.putStringArray("LOCATION", msLocation);
        outState.putStringArray("STRING_ARRAY_DISTANCE",msKmResult);
        outState.putParcelableArray("LISTVIEW_BITMAP_SHOPS_KEY",moBitMapArrayShops);
    }

    public void showToast(String lsString) {
        Toast.makeText(getApplicationContext(), lsString, Toast.LENGTH_SHORT).show();
    }

    private boolean verifyActivityReloadState(Bundle losavedInstanceState) {
        if (losavedInstanceState == null) {
            Log.d(LOG_TAG, " No hay Actividad a Restaurar");
            return false;
        } else {
            Log.d(LOG_TAG, " Se puede restaurar actividad ");
            return true;
        }
    }

    public ArrayList<JsonData> getJsonArray(String lsJsonString, String[] lsFields) {
        ArrayList<JsonData> loaResultJson = new ArrayList<JsonData>();
        JsonParser loParser = new JsonParser(lsFields, lsJsonString);
        loaResultJson = loParser.parse();
        return loaResultJson;
    }

    public String[] getStringArrayFromArrayList(ArrayList<JsonData> loa, int lsFirstField, int lsSecondField) {
        String[] lsArray = new String[loa.size()];

        for (int lii = 0; lii < loa.size(); lii++) {
            lsArray[lii] = loa.get(lii).msFieldbyRow[lsFirstField] + "|" + loa.get(lii).msFieldbyRow[lsSecondField];
        }

        return lsArray;
    }

    public String[] getKmForShops(boolean lbResultCanSave,Bundle losavedInstanceState,String[] lsArray)
    {
        String []  lsKmResult  = new String[moaResultJsonListView.size()];
        if(lbResultCanSave == false )
        {
            for (int i = 0; i < moaResultJsonListView.size(); i++) {
                String[] lastmp = lsArray[i].split("\\|");
                ExecuteHttpRequest getData = new ExecuteHttpRequest();
                try {
                    String lsJsonResult = getData.execute("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + msLocation[0] + "," + msLocation[1] + "&destinations=" + lastmp[0] + "," + lastmp[1] + "&mode=walking&language=en&sensor=false%27").get();
                    parseJsonDistanceData loData = new parseJsonDistanceData(lsJsonResult);
                    loData.parse();
                    lsKmResult [i] = loData.getLsKM();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        }
        else
        {
            lsKmResult = losavedInstanceState.getStringArray("STRING_ARRAY_DISTANCE");
            Log.d(LOG_TAG,"Se Restauro");
        }

        return  lsKmResult;
    }


    public String [] getStringArrayFromArrayListSingleColumn(ArrayList<JsonData> loa,int lsField)
    {
        String [] lsArray = new String[loa.size()];

        for(int lii = 0;lii < loa.size();lii++)
        {
            lsArray [lii] = loa.get(lii).msFieldbyRow[lsField];
        }

        return  lsArray;
    }


    public int [] getIntArrayFromArrayListSingleColumn(ArrayList<JsonData> loa,int lsField)
    {
        int [] lsArray = new int[loa.size()];

        for(int lii = 0;lii < loa.size();lii++)
        {
            lsArray [lii] = Integer.parseInt(loa.get(lii).msFieldbyRow[lsField]);
        }

        return  lsArray;
    }

    public void fillListViewData(boolean lbActivityReloadState, Bundle saveoutState,String [] lsURLsImages,String lsBrandName[],String[] lsDescrip,String [] lsKm,int [] liqualitification)
    {

        if(lbActivityReloadState == false || saveoutState.getParcelableArray("LISTVIEW_BITMAP_SHOPS_KEY") == null)
        {
            GetImageBitmap tg = new GetImageBitmap(this,lsURLsImages);
            try
            {
                moBitMapArrayShops = tg.execute().get();
                //ListViewAdapter loListViewAdapater =  new ListViewAdapter(this,lsBrandName,lsDescrip,moBitMapArrayShops,lsKm);
                ListAdapter loListViewAdapter =  new ListAdapter(this,lsBrandName,lsDescrip,lsKm,moBitMapArrayShops,liqualitification);
                moListViewShops.setAdapter(loListViewAdapter);

            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
        else
        {
            moBitMapArrayShops =  (Bitmap[]) saveoutState.getParcelableArray("LISTVIEW_BITMAP_SHOPS_KEY");
            ListAdapter loListViewAdapter =  new ListAdapter(this,lsBrandName,lsDescrip,lsKm,moBitMapArrayShops,liqualitification);
            moListViewShops.setAdapter(loListViewAdapter);

        }
    }


    private class parseJsonDistanceData {
        String FullJsonString;
        String lsKM;

        public String getLsKM() {
            return lsKM;
        }

        public void setLsKM(String lsKM) {
            this.lsKM = lsKM;
        }

        public parseJsonDistanceData(String lsFullJsonString) {
            this.FullJsonString = lsFullJsonString;
        }

        public void parse() {
            try {


                JSONObject loJsonreader = new JSONObject(FullJsonString.trim());
                String lsDestination = loJsonreader.getString("destination_addresses");
                Log.d(" OUTPUT :: ", lsDestination);
                String lsOrigin = loJsonreader.getString("origin_addresses");
                Log.d(" OUTPUT :: ", lsOrigin);

                JSONArray laoRows = loJsonreader.getJSONArray("rows");// Obtencion de row array
                Log.d(LOG_TAG, laoRows.toString());

                JSONObject lsElemntFromRow = laoRows.getJSONObject(0);//Se Obtiene  la  Pirmera posición , ya que solo hay un elemento
                JSONArray laoElements = lsElemntFromRow.getJSONArray("elements");// Obtencion de elements array
                Log.d(LOG_TAG, laoElements.toString());

                JSONObject loElement = laoElements.getJSONObject(0);//Se Obtiene  la  Pirmera posición , ya que solo hay un elemento
                Log.d(LOG_TAG, loElement.toString());

                JSONObject loDistance = loElement.getJSONObject("distance");
                Log.d(LOG_TAG, loDistance.toString());

                String lsDistance = loDistance.getString("text");
                Log.d(LOG_TAG, lsDistance.toString());
                setLsKM(lsDistance.toString());
                //*** POR AHORA SOLO SE NECESITA EXTRAER LOS KM DE DISTANCIA **//

                /*String lsStatus = loJsonreader.getString("status");
                Log.d(" OUTPUT :: ", lsStatus); */
            } catch (JSONException e) {
                Log.d(LOG_TAG, e.toString());

            }
        }


    }
}