package com.rebollocorp.declubmx;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;

public class deClub_Main_Activity extends AppCompatActivity {
    String LOG_TAG = " deClub_LOG : ";
    private static String msIp = "10.0.0.9";

    /* Data For ViewPager */
    String msJsonResultViewPager =  null;
    ArrayList<JsonData> moaResultJsonViewPager;
    Bitmap [] moBitMapArray;
    ViewPager moViewPagerURL;

    /* Data For Spinner */
    String msJsonResultSpinner =  null;
    Spinner spinnerCategories;
    ArrayList<JsonData> moaResultJsonSpinner;

    /* Location Data */
    LocationService mocationService ;
    LocationManager mocationManager;
    Location moLocation;

    /* ListView Data */
    ListView moListViewShops;
    String msJsonResultListView =  null;
    ArrayList<JsonData> moaResultJsonListView;
    Bitmap [] moBitMapArrayShops;



    /* Others */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xml_declub_main_activity);



        String [] lsArrayOperations = null;
        if(getLocationPermission() == false)
        { showLocationPermission(); }
        else {
            boolean lbResultCanSave = verifyActivityReloadState(savedInstanceState);
            if (verifyInternetConnection() == false) {
                showToast(" deClubMx necesita conexión a internet. ");
                finish();
            } else {
                StartActivity(lsArrayOperations, lbResultCanSave, savedInstanceState);
            }
        }


    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("JSON_STRING_SPINNER",msJsonResultSpinner);
        outState.putString("JSON_STRING_VIEWPAGER",msJsonResultViewPager);
        outState.putParcelableArray("VIEWPAGER_BITMAP_KEY",moBitMapArray);
        outState.putString("JSON_STRING_LISTVIEW",msJsonResultListView);
        outState.putParcelableArray("LISTVIEW_BITMAP_KEY",moBitMapArrayShops);
    }
    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if(Build.VERSION.SDK_INT > 23){moBitMapArray = null;moBitMapArrayShops=null;}
    }
    private void  StartActivity(String [] lsArrayOperations,boolean lbResultCanSave,Bundle savedInstanceState)
    {
        //EditText
        final EditText loEditSearchText=  (EditText) findViewById(R.id.editTextSearch);

        // *  ViewPager  *
        moViewPagerURL = (ViewPager) findViewById(R.id.ViewPagerSliderURL);
        msJsonResultViewPager = getJsonResponse(msJsonResultViewPager,"SELECT|declub_shops.shop_url_image,declub_shops.id_shop|FROM|declub_shops|INNER|JOIN|declub_slider_images|ON|declub_slider_images.id_shop|=|declub_shops.id_shop;",lbResultCanSave,savedInstanceState,"JSON_STRING_VIEWPAGER");
        moaResultJsonViewPager = getJsonArray(msJsonResultViewPager,new String[]{"shop_url_image","id_shop"});
        lsArrayOperations = getStringArrayFromArrayList(moaResultJsonViewPager,0);
        fillViewPagerData(lbResultCanSave,savedInstanceState,lsArrayOperations);
        lsArrayOperations = null;

        // * Spinner  *
        spinnerCategories = (Spinner) findViewById(R.id.spinnerCategories);
        msJsonResultSpinner = getJsonResponse(msJsonResultSpinner,"SELECT|*|FROM|declub_categories",lbResultCanSave,savedInstanceState,"JSON_STRING_SPINNER");
        moaResultJsonSpinner = getJsonArray(msJsonResultSpinner,new String[]{"id_category","description_category","url_image_category"});
        lsArrayOperations = getStringArrayFromArrayList(moaResultJsonSpinner,1);
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this,R.layout.spinner_item_adapter_xml,R.id.txtItem,lsArrayOperations);
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item_adapter_xml);
        spinnerCategories.setAdapter(spinnerArrayAdapter);
        lsArrayOperations = null;

        // ImageButton Location
        final boolean lbResult = callLocationService();
        final ImageButton loImageButtonLocation = (ImageButton) findViewById(R.id.ImageButtonLocation);
        loImageButtonLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loImageButtonLocation.setImageResource(R.drawable.location_image_icon_pressed);
                if(lbResult == true)
                {
                    if(mocationService.isMoHardwareLocationStatus() == true)
                    {
                        Log.d(LOG_TAG," Ubicacion Encendida");
                        showProgressDialog();
                    }
                    else if(mocationService.isMoHardwareLocationStatus() == false)
                    {
                        Log.d(LOG_TAG," Ubicacion apagada");
                        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        showProgressDialog();
                    }
                    else
                    {
                        Log.d(LOG_TAG,"  Otro Evento de Ubicacion");
                    }

                }
                else
                {
                    Toast.makeText(getApplicationContext(), " Imposible encontrar su  ubicacion ", Toast.LENGTH_SHORT).show();
                    //showProgressDialog();

                }
            }
        });
        final Button loBtnSearch = (Button) findViewById(R.id.BtnSearch);
        loBtnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // QUERY POR SHOP
                String lsSearchQuery  = null;
                String lsSearchResult = null;
                if(!spinnerCategories.getSelectedItem().toString().equals("Categorías") || !loEditSearchText.getText().toString().equals(""))
                {

                    if(spinnerCategories.getSelectedItem().toString().equals("Categorías")){lsSearchQuery = "SELECT|id_shop,shop_name,shop_text,shop_latitude,shop_longitude,shop_url_image,shop_qualitification|FROM|declub_shops|WHERE|id_category|=|id_category|AND|shop_name|LIKE|'%25"+ replaceCharacters(loEditSearchText.getText().toString()).replace(" ","|") +"%25'";}else {lsSearchQuery =  "SELECT|id_shop,shop_name,shop_text,shop_latitude,shop_longitude,shop_url_image,shop_qualitification|FROM|declub_shops|WHERE|id_category|=|(SELECT|id_category|FROM|declub_categories|WHERE|description_category|=|'"+ replaceCharacters(spinnerCategories.getSelectedItem().toString()) +"')|AND|shop_name|LIKE|'%25"+ replaceCharacters(loEditSearchText.getText().toString()).replace(" ","|") +"%25'";}

                    lsSearchResult =  getJsonResponseSimpleQuery(lsSearchQuery);
                    if(lsSearchResult.equals("[]") && !loEditSearchText.getText().toString().equals(""))
                    {
                        lsSearchQuery = null; lsSearchQuery = null;
                        lsSearchQuery = "SELECT|DISTINCT|declub_shops.id_shop,declub_shops.shop_name,declub_shops.shop_text,declub_shops.shop_latitude,declub_shops.shop_longitude,declub_shops.shop_url_image,declub_shops.shop_qualitification|FROM|declub_shops|INNER|JOIN|declub_tags|ON|declub_tags.id_shop|=|declub_shops.id_shop|WHERE|declub_tags.shop_tag|LIKE|'%25"+ replaceCharacters(loEditSearchText.getText().toString()).replace(" ","|") +"%25'";
                        lsSearchResult = getJsonResponseSimpleQuery(lsSearchQuery);
                    }
                    if(!lsSearchResult.equals("[]"))
                    {
                        Log.d(LOG_TAG,lsSearchResult);
                        //ArrayList<JsonData> loData = getJsonArray(lsSearchResult,new String[]{"id_shop","shop_name","shop_text","shop_latitude","shop_longitude","shop_url_image","shop_qualitification"});
                        //String [] lsArrayOperations = getStringArrrayFromArrayList(loData,5);
                        //Bitmap [] loResultForIntent  = getBitmapImages(lsArrayOperations);
                        Intent IntentShopsList = new Intent(view.getContext(),deClub_ShopsList_Activity.class);
                        //IntentShopsList.putExtra("BITMAP_RESULT",loResultForIntent);
                        //IntentShopsList.putExtra("Location",new String[]{String.valueOf(moLocation.getLatitude()),String.valueOf(moLocation.getLongitude())});
                        IntentShopsList.putExtra("JSON_RESULT",lsSearchResult);
                        IntentShopsList.putExtra("LOCATION",new String []{"19.625107","-99.317710"});

                        startActivity(IntentShopsList);

                    }
                    else
                    {
                        showToast("No se encontraron resultados para su búsqueda.");
                    }
                }
                else
                {
                    showToast("Porfavor, haga una búsqueda o elija una catagoria. ");
                }



                /*if(moLocation != null)//Comantado solo para puevas de ShopList Activity
                {


                    /*Intent IntentShopsList = new Intent(view.getContext(),deClub_ShopsList_Activity.class);
                    IntentShopsList.putExtra("Location",new String[]{String.valueOf(moLocation.getLatitude()),String.valueOf(moLocation.getLongitude())});

                    startActivity(IntentShopsList);


                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Porfavor pulse el boton de ubicacion", Toast.LENGTH_SHORT).show();

                    //CODIGo unicamnete para pruebas en emulador android
                    Intent IntentShopsList = new Intent(view.getContext(),deClub_ShopsList_Activity.class);
                    IntentShopsList.putExtra("Location",new String[]{"19.625107","-99.317710"});
                    startActivity(IntentShopsList);
                } */
            }
        });

        // Problema con Rotacion de pantalla para los listview
        moListViewShops =  (ListView) findViewById(R.id.layoutListShops);
        msJsonResultListView  = getJsonResponse(msJsonResultListView,"SELECT|id_shop,shop_name,shop_text,shop_url_image,shop_qualitification|FROM|declub_shops",lbResultCanSave,savedInstanceState,"JSON_STRING_LISTVIEW");
        moaResultJsonListView = getJsonArray(msJsonResultListView,new String[]{"id_shop","shop_name","shop_text","shop_url_image", "shop_qualitification"});
        ArrayList<String> lasRandomArray = getRandomArray(moaResultJsonListView.size());
        final String []IdShops  = new String[]{moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(0))).msFieldbyRow[0],moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(1))).msFieldbyRow[0],moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(2))).msFieldbyRow[0]};
        final String []msShopsNames = new String[]{moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(0))).msFieldbyRow[1],moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(1))).msFieldbyRow[1],moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(2))).msFieldbyRow[1]};
        String []msShopsText =  new String[]{moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(0))).msFieldbyRow[2],moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(1))).msFieldbyRow[2],moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(2))).msFieldbyRow[2]};
        String []msShopsImg = new String[]{moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(0))).msFieldbyRow[3],moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(1))).msFieldbyRow[3],moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(2))).msFieldbyRow[3]};
        int []msShopsqualitification =  new int[]{Integer.parseInt(moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(0))).msFieldbyRow[4]),Integer.parseInt(moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(1))).msFieldbyRow[4]),Integer.parseInt(moaResultJsonListView.get(Integer.parseInt(lasRandomArray.get(2))).msFieldbyRow[4])};
        fillListViewData(lbResultCanSave,savedInstanceState,msShopsImg,msShopsNames,msShopsText,new String []{"","",""},msShopsqualitification);
        moListViewShops.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                 Intent loIntentViewShop = new Intent(view.getContext(),deClub_ViewShopItem_Activity.class);
                 loIntentViewShop.putExtra("DATA_ID",IdShops[i]);
                 startActivity(loIntentViewShop);

            }
        });



    }
    private boolean getLocationPermission()
    {
        if( ActivityCompat.checkSelfPermission(deClub_Main_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED  || ActivityCompat.checkSelfPermission(deClub_Main_Activity.this, Manifest
                .permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED )
        {
            Log.d(LOG_TAG,"Si Tiene Permisos");
            return true;
        }
        else
        {

            Log.d(LOG_TAG,"NO Tiene Permisos");
            return false;
        }
    }
    public void showToast(String lsString)
    {
        Toast.makeText(getApplicationContext(),lsString,Toast.LENGTH_SHORT).show();
    }
    public void showLocationPermission()
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(" Por favor, asigne permisos y reinicie la aplicación. ")
                .setCancelable(false)
                .setNeutralButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityCompat.requestPermissions(deClub_Main_Activity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                        SystemClock.sleep(2000);
                        finish();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();

    }
    private boolean verifyInternetConnection() {

        ConnectivityManager connectivityManager = (ConnectivityManager)  getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo actNetInfo = connectivityManager.getActiveNetworkInfo();
        return (actNetInfo != null && actNetInfo.isConnected());
    }
    private  boolean verifyActivityReloadState(Bundle losavedInstanceState)
    {
        if (losavedInstanceState == null) { Log.d(LOG_TAG," No hay Actividad a Restaurar"); return false;}else{Log.d(LOG_TAG," Se puede restaurar actividad ");return true;}
    }
    public ArrayList<JsonData> getJsonArray(String lsJsonString,String [] lsFields)
    {
        ArrayList<JsonData> loaResultJson  = new ArrayList<JsonData>();
        JsonParser loParser = new JsonParser(lsFields,lsJsonString);
        loaResultJson = loParser.parse();
        return  loaResultJson;
    }
    public String [] getStringArrayFromArrayList(ArrayList<JsonData> loa,int lsField)
    {
        String [] lsArray = new String[loa.size()];

            for(int lii = 0;lii < loa.size();lii++)
            {
                lsArray [lii] = loa.get(lii).msFieldbyRow[lsField];
            }

        return  lsArray;
    }
    public void fillViewPagerData(boolean lbActivityReloadState, Bundle saveoutState,String [] lsURLsImages)
    {
        if(lbActivityReloadState == false || saveoutState.getParcelableArray("VIEWPAGER_BITMAP_KEY") == null)
        {
            GetImageBitmap tg = new GetImageBitmap(this,lsURLsImages);
            try
            {
                moBitMapArray = tg.execute().get();
                PageViewAdapter loViewPagerAdapater =  new PageViewAdapter(this,moBitMapArray);
                moViewPagerURL.setAdapter(loViewPagerAdapater);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
        else
        {
            moBitMapArray =  (Bitmap[]) saveoutState.getParcelableArray("VIEWPAGER_BITMAP_KEY");
            PageViewAdapter loViewPagerAdapater =  new PageViewAdapter(this,moBitMapArray);
            moViewPagerURL.setAdapter(loViewPagerAdapater);
        }

    }
    public void fillListViewData(boolean lbActivityReloadState, Bundle saveoutState,String [] lsURLsImages,String lsBrandName[],String[] lsDescrip,String [] lsKm, int [] liQualitification)
    {

        if(lbActivityReloadState == false || saveoutState.getParcelableArray("LISTVIEW_BITMAP_KEY") == null)
        {
            GetImageBitmap tg = new GetImageBitmap(this,lsURLsImages);
            try
            {
                moBitMapArrayShops = tg.execute().get();
                ListAdapter loListViewAdapter =  new ListAdapter(this,lsBrandName,lsDescrip,lsKm,moBitMapArrayShops,liQualitification);
                moListViewShops.setAdapter(loListViewAdapter);

            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
        else
        {
            moBitMapArrayShops =  (Bitmap[]) saveoutState.getParcelableArray("LISTVIEW_BITMAP_KEY");
            ListAdapter loListViewAdapter =  new ListAdapter(this,lsBrandName,lsDescrip,lsKm,moBitMapArrayShops,liQualitification);
            moListViewShops.setAdapter(loListViewAdapter);

        }
    }
    public String getJsonResponse(String lsStringJson,String lsQuery,boolean lbResultCanSave,Bundle saveoutState,String lsKey)
    {
        if(lbResultCanSave == false )
        {
            ExecuteHttpRequest loJsonMainData = new ExecuteHttpRequest();
            try {
                lsStringJson = loJsonMainData.execute("http://" + msIp + "/declubmx/executeQuery.php?query=" + lsQuery).get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            return  lsStringJson;
        }
        else
        {
            lsStringJson =  saveoutState.getString(lsKey);
            return lsStringJson;
        }

    }
    public String getJsonResponseSimpleQuery(String lsQuery)
    {
        String lsStringJson = null;
        ExecuteHttpRequest loJsonMainData = new ExecuteHttpRequest();
        try {
            lsStringJson = loJsonMainData.execute("http://" + msIp + "/declubmx/executeQuery.php?query=" + lsQuery).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return  lsStringJson;
    }
    public boolean callLocationService()
    {

        mocationService =  new LocationService(deClub_Main_Activity.this);
        mocationManager = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
        List<String> loProviders = mocationManager.getAllProviders();
        if(loProviders.contains("network")  == true)
        {
            int permissionCheck = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
            int permissionCheck2 = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION);
            mocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1000,0, mocationService);
            return  true;
        }
        else
        {
            //Toast.makeText(getApplicationContext(), " Imposible encontrar su  ubicacion ", Toast.LENGTH_SHORT).show();

             /*   int permissionCheck = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
                int permissionCheck2 = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION);
                mocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0, mocationService); */

            return  false;
        }


    }
    public  void showProgressDialog()
    {
        final ProgressDialog moProgress = new ProgressDialog(deClub_Main_Activity.this);
        moProgress.setMessage("Encontrando su ubicacion");
        moProgress.setCancelable(false);
        moProgress.show();

        final Timer loTimerLocation = new Timer();
        TimerTask loTaskTimerLocation = new TimerTask() {

            @Override
            public void run()
            {

                if(mocationService.getMoLocation() == null )
                {
                    Log.d(LOG_TAG,"Es null ");


                }
                else
                {

                    Log.d(LOG_TAG,"NO ES null ");
                    loTimerLocation.cancel();
                    moProgress.dismiss();
                    moLocation = mocationService.getMoLocation();
                    Log.d(LOG_TAG,String.valueOf(mocationService.getMoLocation().getLatitude() +","+mocationService.getMoLocation().getLongitude()));
                    mocationService.setMoLocation(null);
                }
            }
        };
        loTimerLocation.schedule(loTaskTimerLocation,0,1000);
    }
    public ArrayList<String> getRandomArray(int liiLimit)
    {
        Random lornd = new Random();
        ArrayList<String> loax = new ArrayList<String>();
        boolean b = false;
        while(b == false)
        {
            int liitmp =  lornd.nextInt(liiLimit);
            if(liitmp  >= 0)
            {

                if(loax.contains(String.valueOf(liitmp)))
                {
                    Log.d(LOG_TAG," Repetido : ");
                }
                else
                {
                    loax.add(String.valueOf(liitmp));

                    if(loax.size() == 3)
                    {
                        b = true;
                    }
                }

            }
        }
        //Log.d(LOG_TAG, String.valueOf(loax));
        return loax;
    }
    public String ExecuteSqlBatch(String lsQuery)
    {
        ExecuteHttpRequest loRequest = new ExecuteHttpRequest();
        String lsResult = null;
        try {
            lsResult = loRequest.execute("http://" + msIp + "/declubmx/executeCommand.php?query=" + lsQuery).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return lsResult;
    }
    public  String replaceCharacters(String input) {

        String normalized = Normalizer.normalize(input, Normalizer.Form.NFD);
        // Nos quedamos únicamente con los caracteres ASCII
        Pattern pattern = Pattern.compile("\\P{ASCII}+");
        return pattern.matcher(normalized).replaceAll("");
    }
    public Bitmap[] getBitmapImages(String []lsURLsImages)
    {

        GetImageBitmap tg = new GetImageBitmap(this,lsURLsImages);
        Bitmap []loResultbitMap = null;
        try {
            loResultbitMap = tg.execute().get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return loResultbitMap;
    }
}
