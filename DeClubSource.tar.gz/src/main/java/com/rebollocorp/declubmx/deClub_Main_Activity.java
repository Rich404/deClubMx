package com.rebollocorp.declubmx;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.concurrent.ExecutionException;

public class deClub_Main_Activity extends AppCompatActivity {
    String LOG_TAG = " deClub_LOG : ";
    ViewPager moViewPagerURL; Bitmap[] moBitMapArray ;// Control y su ArrayBitmap

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xml_declub_main_activity);

        moViewPagerURL = (ViewPager) findViewById(R.id.ViewPagerSliderURL);

        if(getLocationPermission() == false) { showLocationPermission(); }
        if(verifyInternetConnection() == false) { showToast(" deClubMx necesita conexión a internet. ");finish();}
        boolean lbReloadResult =  verifyActivityReloadState(savedInstanceState);
        fillViewPagerData(lbReloadResult);


    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d(LOG_TAG,"Se Recargará Actividad");

        moBitMapArray =  (Bitmap[]) savedInstanceState.getParcelableArray("VIEWPAGER_BITMAP_KEY");
        PageViewAdapter loViewPagerAdapater =  new PageViewAdapter(this,moBitMapArray);
        moViewPagerURL.setAdapter(loViewPagerAdapater);

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //outState.putString("X_KEY_STATE",X);
        Log.d(LOG_TAG," Tamaño a guardar ***: " + moBitMapArray.length);
        outState.putParcelableArray("VIEWPAGER_BITMAP_KEY",moBitMapArray);

    }


    public void fillViewPagerData(boolean lbActivityReloadState)
    {
        if(lbActivityReloadState == false)
        {
            GetImageBitmap tg = new GetImageBitmap(this,new String[]
                    {"http://eltriangulo.mx/multimedia/imagenes/directorio/4176aaf0c81caf62375caa44aabba6533310066b.jpg",
                            "http://i.anunciosya.com.mx/i-a/Rdwo-1.jpeg",
                            "http://4.bp.blogspot.com/-Uc3f6-glrEs/T8_YO4SlfLI/AAAAAAAAABY/Zb7mnHxS0Ho/s1600/Escuela.jpg",
                            "http://www.vanguardia.com.mx/sites/default/files/pizza-pepperoni-w857h456_0.jpg"});
            try
            {
                moBitMapArray = tg.execute().get();
                PageViewAdapter loViewPagerAdapater =  new PageViewAdapter(this,moBitMapArray);
                moViewPagerURL.setAdapter(loViewPagerAdapater);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }

    }

    private  boolean verifyActivityReloadState(Bundle losavedInstanceState)
    {
        if (losavedInstanceState == null) { Log.d(LOG_TAG," No hay Actividad a Restaurar"); return false;}else{Log.d(LOG_TAG," Se puede restaurar actividad ");return true;}
    }
    private boolean verifyInternetConnection() {

        ConnectivityManager connectivityManager = (ConnectivityManager)  getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo actNetInfo = connectivityManager.getActiveNetworkInfo();
        return (actNetInfo != null && actNetInfo.isConnected());
    }

    private boolean getLocationPermission()
    {
        if( ActivityCompat.checkSelfPermission(deClub_Main_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED  || ActivityCompat.checkSelfPermission(deClub_Main_Activity.this, Manifest
                .permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED )
        {
            Log.d(LOG_TAG,"Si Tiene Permisos");
            return true;
        }
        else
        {

            Log.d(LOG_TAG,"NO Tiene Permisos");
            return false;
        }
    }
    public void showToast(String lsString)
    {
        Toast.makeText(getApplicationContext(),lsString,Toast.LENGTH_SHORT).show();
    }

    public void showLocationPermission()
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(" Por favor, asigne permisos y reinicie la aplicación. ")
                .setCancelable(false)
                .setNeutralButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityCompat.requestPermissions(deClub_Main_Activity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                        SystemClock.sleep(2000);
                        finish();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();

    }

}
