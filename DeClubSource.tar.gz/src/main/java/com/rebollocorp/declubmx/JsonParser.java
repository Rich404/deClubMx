package com.rebollocorp.declubmx;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by hpadmin on 11/08/17.
 */

public class JsonParser {
    String[] msFields;
    String msJsonSource;

    JsonParser (String[] lsfields,String loJsonSource){
        msFields = lsfields;
        msJsonSource = loJsonSource;
    }

    public ArrayList<JsonData>  parse()
    {
        ArrayList<JsonData>  ArrayListJsonData = new ArrayList<JsonData>();
        try
        {
            JSONArray lojsonArray = new JSONArray(msJsonSource);
            for(int i=0;i<lojsonArray.length();i++)
            {

                JsonData loJsonData = new JsonData();
                JSONObject loObj = lojsonArray.getJSONObject(i);
                loJsonData.setLsRow("Row : "+String.valueOf(i));
                String[] lsFieldbyRow = new String[msFields.length];
                for (int j=0;j<msFields.length;j++)
                {
                    lsFieldbyRow [j] = loObj.getString(msFields[j]);
                }
                loJsonData.setMsFieldbyRow(lsFieldbyRow);
                ArrayListJsonData.add(loJsonData);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  ArrayListJsonData;
    }
}
