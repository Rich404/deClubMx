package com.rebollocorp.declubmx;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.URL;

/**
 * Created by hpadmin on 8/07/17.
 */

public class PageViewAdapter extends PagerAdapter{

    Context goContext;
    Bitmap [] loaBitMap;

    public PageViewAdapter(Context goContext, Bitmap[] loaBitMap) {
        this.goContext = goContext;
        this.loaBitMap = loaBitMap;
    }

    @Override
    public int getCount() {
        return loaBitMap.length;
    }


    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((ImageView) object);
    }
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        ((ViewPager) container).removeView((ImageView) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        ImageView imageView = new ImageView(goContext);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LoadImageWithBitMap lo = new LoadImageWithBitMap(imageView);
        lo.execute(loaBitMap[position]);
        ((ViewPager) container).addView(imageView,0);
        return imageView;
    }

}
