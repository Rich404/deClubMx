package com.rebollocorp.declubmx;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

/**
 * Created by hpadmin on 20/09/17.
 */

public class ListViewAdapterOpinions extends BaseAdapter {

    Context mContext;
    String [] msUser,msOpinion,msStarsOpinion;

    public ListViewAdapterOpinions(Context mContext, String[] msUser, String[] msOpinion, String[] msStarsOpinion) {
        this.mContext = mContext;
        this.msUser = msUser;
        this.msOpinion = msOpinion;
        this.msStarsOpinion = msStarsOpinion;

    }

    static class ViewHolder {
        TextView txtUser;
        TextView txtOpinion;
        RatingBar ratingbarOpinion;
    }


    @Override
    public int getCount() {
        return msUser.length;
    }

    @Override
    public Object getItem(int i) {
        return msUser[i];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        View rowView = convertView;

        // reuse views
        if (rowView == null) {
            LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
            rowView = inflater.inflate(R.layout.list_view_opinions_adaper, null);

            ListViewAdapterOpinions.ViewHolder viewHolder = new ListViewAdapterOpinions.ViewHolder();
            viewHolder.txtUser = (TextView) rowView.findViewById(R.id.txtNameOpinion);
            viewHolder.txtOpinion = (TextView) rowView.findViewById(R.id.txtOpinion);
            viewHolder.ratingbarOpinion = (RatingBar) rowView.findViewById(R.id.ratingBarOpinion);

            rowView.setTag(viewHolder);
        }

        ListViewAdapterOpinions.ViewHolder holder = (ListViewAdapterOpinions.ViewHolder) rowView.getTag();
        holder.txtUser.setText(msUser[i]);
        holder.txtOpinion.setText(msOpinion[i]);
        holder.ratingbarOpinion.setRating(Float.parseFloat(msStarsOpinion[i]));

        return rowView;
    }
}
