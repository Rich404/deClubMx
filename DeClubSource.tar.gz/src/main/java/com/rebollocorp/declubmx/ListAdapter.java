package com.rebollocorp.declubmx;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

/**
 * Created by hpadmin on 4/09/17.
 */

public class ListAdapter  extends BaseAdapter {


    Context mContext;
    String[] msName,msText,msKm;
    Bitmap[] moBitmap;
    int [] miQualitification;

    static class ViewHolder {
        ImageView image;
        TextView shopname;
        TextView text;
        TextView km;
        RatingBar ratingbar;
    }

    public ListAdapter(Context mContext, String[] msName, String[] msText, String[] msKm, Bitmap[] moBitmap,int [] miQualitification) {
        this.mContext = mContext;
        this.msName = msName;
        this.msText = msText;
        this.msKm = msKm;
        this.moBitmap = moBitmap;
        this.miQualitification = miQualitification;
    }

    @Override
    public int getCount() {
        return moBitmap.length;
    }


    @Override
    public Object getItem(int i) {
        return msName[i];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        View rowView = convertView;

        // reuse views
        if (rowView == null) {
            LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
            rowView = inflater.inflate(R.layout.list_view_adapter, null);

            ViewHolder viewHolder = new ViewHolder();
            viewHolder.image = (ImageView) rowView.findViewById(R.id.imageViewBrand);
            viewHolder.shopname = (TextView) rowView.findViewById(R.id.lbltitle);
            viewHolder.text = (TextView) rowView.findViewById(R.id.lblDescription);
            viewHolder.km = (TextView) rowView.findViewById(R.id.lblDistanceKM);
            viewHolder.ratingbar = (RatingBar) rowView.findViewById(R.id.ratingBarShop);
            rowView.setTag(viewHolder);
        }

        ViewHolder holder = (ViewHolder) rowView.getTag();
        LoadImageWithBitMap loLoadImageBitmap =  new LoadImageWithBitMap(holder.image);
        loLoadImageBitmap.execute(moBitmap[i]);
        holder.shopname.setText(msName[i]);
        holder.text.setText(msText[i]);
        holder.km.setText(msKm[i]);
        holder.ratingbar.setNumStars(miQualitification[i]);
        return rowView;

    }
}
