<?php

	$servername = "localhost";
	$username = "root";
	$password = "admin";
        $dbname = "declubmx_app_maintenance";
	$connetionObj = mysqli_connect($servername, $username, $password,$dbname);
	 mysqli_set_charset($connetionObj, "utf8"); //formato de datos utf8
	if ($connetionObj == false)
	{
		die("Error en la conexion: " . mysqli_connect_error());	
	}
	else
	{
		//echo "Conexion establecida";
		$sqlQuery = str_replace("|"," ",$_GET["query"]) . ";";
		//echo "<br>"."Se ejecutara: ". $sqlQuery . "<br>";
		if (mysqli_query($connetionObj, $sqlQuery)) 
		{
		    echo "[{\"batch_status\":\"1\"}]"; // 1 Para Exitoso
		} 
		else 
		{
		   echo "[{\"batch_status\":\"2\"}]"; // 2 Para Error
		} 
	}
	mysqli_close($connetionObj);
	
?>
